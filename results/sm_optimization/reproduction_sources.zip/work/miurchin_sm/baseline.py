from pathlib import Path
import csv,json,collections,itertools
root=Path(__file__).resolve().parents[2];p=Path(__file__).parent;repo=root/'outputs/MiUrchin'
rr=list(csv.DictReader((repo/'results/pairings.csv').open(encoding='utf-8-sig')));hits=collections.defaultdict(set)
for r in csv.DictReader((repo/'analysis/independent_hits.tsv').open(),delimiter='\t'):
 for k in ['exact','le2last3','le2','le3','le4']:
  if r[k]=='1':hits[r['name'],r['role'],r['model'],k].add(r['accession'])
panel=json.loads((root/'work/miurchin_mifish/panel.json').read_text());w={r['accession']:float(r['weight']) for r in panel};den=sum(w.values())
results=[];selected=[]
for reg,old in [('S','XS'),('M','S')]:
 pool={r['pair_result_id']:r for r in rr if r['scheme'].startswith('MiUrchin-'+old+'-')};pairs=list(pool)
 for num in [1,2]:
  best=None;choice=None
  for ns in itertools.combinations(pairs,num):
   def union(role,model,k):return set().union(*(hits[n,role,model,k] for n in ns))
   b=union('background','WC','le3');g=union('background','GT','le2')
   if len(b)>5 or len(g)>5:continue
   cv=100*sum(w.get(a,0) for a in union('target','WC','le2last3'))/den;ex=100*sum(w.get(a,0) for a in union('target','WC','exact'))/den
   score=(cv,ex,-len(b)-len(g))
   if best is None or score>best:best=score;choice=ns
  print(reg,num,best,choice)
  for n in choice:selected.append(dict(pool[n],region=reg,option=num))
(p/'baseline_selected.json').write_text(json.dumps(selected,indent=2))
