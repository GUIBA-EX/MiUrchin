from pathlib import Path
import json,sys,itertools,functools,math
import numpy as np
from Bio.Data.IUPACData import ambiguous_dna_values as I
p=Path(__file__).resolve().parent;root=p.parents[1];sys.path.insert(0,str(root/'work/micucumber_mifish/deps'));import primer3
rr=json.loads((p/'pool.json').read_text());panel=json.loads((root/'work/miurchin_mifish/panel.json').read_text());w=np.array([x['weight'] for x in panel]);w/=w.sum()
# Include the previously screened shifted-window ordinary candidates with their original state vectors.
old=json.loads((root/'work/miurchin_mifish/specific/feasible.json').read_text());states=json.loads((root/'work/miurchin_mifish/specific/oligo_states.json').read_text())
for r in old:
 if r['region'] not in ['S','M']:continue
 rr.append(dict(r,source='mifish_shifted',degeneracy_F=1,degeneracy_R=1,cv=(np.array(states[r['F_id']]['coverage'])&states[r['R_id']]['coverage']).tolist(),ex=(np.array(states[r['F_id']]['exact'])&states[r['R_id']]['exact']).tolist()))
kw=dict(mv_conc=50,dv_conc=1.5,dntp_conc=.6)
@functools.lru_cache(None)
def expand(q):return list(map(''.join,itertools.product(*(I[c] for c in q))))
@functools.lru_cache(None)
def single(q,c):return primer3.calc_tm(q,dna_conc=c,**kw),max(primer3.calc_hairpin(q,dna_conc=c,**kw).tm,primer3.calc_homodimer(q,dna_conc=c,**kw).tm)
@functools.lru_cache(None)
def hetero(a,b,c):return primer3.calc_heterodimer(a,b,dna_conc=c,**kw).tm
@functools.lru_cache(None)
def thermal(F,R):
 fs,rs=expand(F),expand(R);maxst=-100;report=[]
 for scenario in ['50_per_variant','200_per_direction']:
  fc=50 if scenario=='50_per_variant' else 200/len(fs);rc=50 if scenario=='50_per_variant' else 200/len(rs);ft=[single(q,fc) for q in fs];rt=[single(q,rc) for q in rs]
  st=max(v[1] for v in ft+rt)
  for a,b in itertools.combinations(fs,2):st=max(st,hetero(a,b,fc))
  for a,b in itertools.combinations(rs,2):st=max(st,hetero(a,b,rc))
  for a,b in itertools.product(fs,rs):st=max(st,hetero(a,b,max(fc,rc)))
  report.append(dict(scenario=scenario,F_tm_min=min(x[0] for x in ft),F_tm_max=max(x[0] for x in ft),R_tm_min=min(x[0] for x in rt),R_tm_max=max(x[0] for x in rt),structure_max=st));maxst=max(maxst,st)
 return maxst<55,report
selected=[];audit=[]
for reg in ['S','M']:
 for chemistry in ['ordinary','degenerate']:
  for count in [1,2]:
   pool=[r for r in rr if r['region']==reg and (chemistry=='degenerate' or r['degeneracy_F']*r['degeneracy_R']==1)]
   # Same target/background state: keep lowest degeneracy to limit dilution.
   unique={}
   for r in pool:
    key=(tuple(r['cv']),tuple(r['ex']),tuple(r['WC3']),tuple(r['GT2']))
    if key not in unique or r['degeneracy_F']+r['degeneracy_R']<unique[key]['degeneracy_F']+unique[key]['degeneracy_R']:unique[key]=r
   pool=list(unique.values());failures=0
   while True:
    best=None;chosen=None
    for pp in itertools.combinations(pool,count):
     if chemistry=='degenerate' and not any(x['degeneracy_F']*x['degeneracy_R']>1 for x in pp):continue
     wc=set().union(*(set(x['WC3']) for x in pp));gt=set().union(*(set(x['GT2']) for x in pp))
     if len(wc)>5 or len(gt)>5:continue
     cv=np.logical_or.reduce([x['cv'] for x in pp]);ex=np.logical_or.reduce([x['ex'] for x in pp])
     floor={('S',1):(.4081632653,.2040816326),('S',2):(.6122448979,.2040816326),('M',1):(.3673469387,.0612244897),('M',2):(.4693877551,.0816326530)}[reg,count]
     if float(w@cv)+1e-8<floor[0] or float(w@ex)+1e-8<floor[1]:continue
     score=(float(w@cv),float(w@ex),-sum(x['degeneracy_F']+x['degeneracy_R'] for x in pp),-len(wc)-len(gt))
     if best is None or score>best:best=score;chosen=pp
    if chosen is None:raise RuntimeError((reg,chemistry,count,'no viable candidates'))
    bad=[r for r in chosen if not thermal(r['F'],r['R'])[0]]
    if not bad:break
    failures+=len(bad);pool=[r for r in pool if all((r['F'],r['R'])!=(b['F'],b['R']) for b in bad)]
   stem=reg+('D' if chemistry=='degenerate' else '');scheme=stem if count==1 else stem+'A+'+stem+'B'
   for i,r in enumerate(chosen):selected.append(dict(r,scheme=scheme,name=stem if count==1 else stem+chr(65+i),option=count,chemistry=chemistry,union_coverage=best[0],union_exact=best[1],thermal=thermal(r['F'],r['R'])[1]))
   audit.append(dict(scheme=scheme,distinct_candidates=len(pool),thermal_rejections=failures,coverage=best[0],exact=best[1]));print(audit[-1],flush=True)
# Reuse genuine degenerate pair names; ordinary supplements never receive D.
for r in selected:
 if r['scheme']=='SDA+SDB':
  r['scheme']='SD+SB';r['name']='SD' if r['degeneracy_F']*r['degeneracy_R']>1 else 'SB';r['chemistry']='mixed'
 if r['scheme']=='MDA+MDB':
  r['scheme']='MD+MC';r['name']='MD' if r['degeneracy_F']*r['degeneracy_R']>1 else 'MC';r['chemistry']='mixed'
(p/'selected.json').write_text(json.dumps(selected,indent=2));(p/'audit.json').write_text(json.dumps(audit,indent=2));print('DONE',flush=True)
