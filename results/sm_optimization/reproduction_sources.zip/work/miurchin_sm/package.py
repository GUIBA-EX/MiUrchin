from pathlib import Path
import csv,json,shutil,zipfile,collections
root=Path(__file__).resolve().parents[2];p=Path(__file__).resolve().parent;repo=root/'outputs/MiUrchin';dest=repo/'results/sm_optimization';dest.mkdir(exist_ok=True);current=repo/'results/current';current.mkdir(exist_ok=True)
for f in (p/'release').iterdir():
 if f.suffix=='.svg':shutil.copy2(f,repo/'figures'/f.name)
 else:shutil.copy2(f,dest/f.name)
shutil.copy2(p/'verify/independent_hits.tsv',dest/'independent_hits.tsv');shutil.copy2(p/'audit.json',dest/'search_audit.json')
def read(f):return list(csv.DictReader(f.open()))
def write(f,rows):
 with f.open('w') as h:
  w=csv.DictWriter(h,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
comp=read(dest/'comparison.csv');old=[r for r in read(repo/'results/compact/comparison.csv') if r['region'] in ['L','XL']]
for r in old:r['chemistry']='ordinary'
fields=list(comp[0]);write(current/'comparison.csv',comp+[{k:r[k] for k in fields} for r in old])
new=read(dest/'primer_pairs.csv');pairs=[{k:r[k] for k in ['scheme','region','name','F','R','degeneracy_F','degeneracy_R']} for r in new]
for r in read(repo/'results/compact/primer_pairs.csv'):
 if r['region'] in ['L','XL']:pairs.append(dict(scheme=r['scheme'],region=r['region'],name=r['name'],F=r['F'],R=r['R'],degeneracy_F=1,degeneracy_R=1))
write(current/'primer_pairs.csv',pairs);unique={r['name']:r for r in pairs};(current/'primers.fasta').write_text(''.join(f">{r['name']}_{side}\n{r[side]}\n" for r in unique.values() for side in ['F','R']))
for zh in [False,True]:
 f=repo/('README.zh-CN.md' if zh else 'README.md');s=f.read_text();a=s.index('| Scheme |');b=s.index('\n\n',a);table='| Scheme | Type | Pairs | Coverage | Exact | WC≤3 | GT≤2 | WC≤4 |\n|---|---|---:|---:|---:|---:|---:|---:|\n'
 for r in comp+old:table+=f"| {r['scheme']} | {r['chemistry']} | {r['pairs']} | {float(r['coverage_pct']):.2f}% | {float(r['exact_pct']):.2f}% | {r['WC3']} | {r['GT2']} | {r['WC4']} |\n"
 s=s[:a]+table.rstrip()+s[b:]
 a=s.index('**选择建议：**' if zh else '**Selection guidance:**');b=s.index('## 序列与证据' if zh else '## Sequences and evidence',a)
 note=('**优先比较SD和MD单对。** SD覆盖65.31%、完全匹配38.78%；MD为87.76%和48.98%。补充普通引物后，SD+SB升至79.59%覆盖，MD+MC升至93.88%覆盖、55.10%完全匹配。两者都是一对简并加一对普通引物的独立PCR并集。\n\nM普通单对也提高至59.18%覆盖、16.33%完全匹配；普通两对为77.55%和16.33%。S普通方案尚未改善。SD和MD均为F 12重、R 24重简并；同向总浓度固定时，每种实际序列的浓度会被分摊。完全匹配按IUPAC相容计算，不代表所有变体均匹配，也不等同于实验效率。\n\n' if zh else '**Prioritize SD and MD single-pair comparisons.** SD reaches 65.31% coverage and 38.78% exact matching; MD reaches 87.76% and 48.98%. Adding an ordinary pair gives 79.59% coverage for SD+SB, and 93.88% coverage / 55.10% exact matching for MD+MC. These are separate-PCR unions of one degenerate and one ordinary pair.\n\nOrdinary M improves to 59.18% coverage / 16.33% exact matching; its two-pair option reaches 77.55% / 16.33%. Ordinary S remains unchanged. SD and MD each have 12-fold F and 24-fold R degeneracy; a fixed directional concentration is divided among concrete variants. Exact matching means IUPAC compatibility, not that every variant matches or that amplification efficiency is established.\n\n')
 s=s[:a]+note+s[b:]
 s=s.replace('results/compact/primer_pairs.csv','results/current/primer_pairs.csv').replace('results/compact/primers.fasta','results/current/primers.fasta').replace('results/compact/comparison.csv','results/current/comparison.csv').replace('results/compact/missed_references.csv','results/sm_optimization/missed_references.csv').replace('results/compact/verification.json','results/sm_optimization/verification.json').replace('results/compact/base_matching.html','results/sm_optimization/base_matching.html')
 s=s.replace('single-pair and two-pair','single-pair and two-pair')
 oldintro='Mitochondrial 16S primers for sea urchins. MiFish-inspired base-level consensus design searches four length windows and selects one-pair and two-pair separate-PCR options.'
 s=s.replace(oldintro,'Mitochondrial 16S primers for sea urchins. Four length windows retain one-pair and two-pair separate-PCR options, with ordinary, degenerate and complementary mixed options for S and M.').replace('海胆线粒体16S引物：参考MiFish的逐位点共识设计，在四个长度窗口搜索普通引物，并精简为单对与两对独立PCR方案。','海胆线粒体16S引物：四个长度窗口保留单对与两对独立PCR方案，S和M同时比较普通、简并及互补组合。')
 marker='## 方案比较' if zh else '## Portfolio comparison'
 naming=('D仅用于简并配对；SD+SB与MD+MC分别表示简并单对加普通补充配对。MC是针对MD的普通补充引物。当前12套方案、18条配对记录，复用名称去重后为15个配对名、30条FASTA记录。\n\n' if zh else 'D identifies a degenerate pair. SD+SB and MD+MC combine a degenerate pair with an ordinary supplement; MC is the ordinary supplement selected for MD. There are 12 portfolios and 18 paired entries, with 15 unique pair names / 30 FASTA records after name reuse is deduplicated.\n\n')
 s=s.replace(marker,naming+marker)
 for reg in ['S','M']:s=s.replace(f'![{reg} base matching](figures/base_matching_{reg}.svg)',f'![{reg} base matching](figures/base_matching_{reg}.svg)\n\n![{reg}D base matching](figures/base_matching_{reg}D.svg)')
 s=s.replace('blue = match','blue = IUPAC-compatible').replace('蓝色表示相同','蓝色表示IUPAC相容')
 f.write_text(s)
files=[*p.glob('*.py'),p/'pool.json',p/'selected.json',p/'audit.json',root/'work/miurchin_mifish/panel.json',root/'work/miurchin_mifish/specific/feasible.json',root/'work/miurchin_mifish/specific/oligo_states.json',root/'work/miurchin_mifish/specific/oligos.csv',root/'work/micucumber_nondegenerate/independent_scan.cpp',repo/'analysis/target.fasta',repo/'analysis/background.fasta',repo/'analysis/target_aligned.fasta']
for src in ['same_locus','same_locus_common_panel']:files.append(root/'work/miurchin'/src/'oligos.json')
with zipfile.ZipFile(dest/'reproduction_sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,f.relative_to(root))
print('current records',len(pairs),'unique',len(unique))
