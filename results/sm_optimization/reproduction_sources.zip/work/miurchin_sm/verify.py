from pathlib import Path
import json,csv,subprocess
p=Path(__file__).resolve().parent;root=p.parents[1];v=p/'verify';v.mkdir(exist_ok=True);r=json.loads((p/'selected.json').read_text());(v/'independent_primers.tsv').write_text(''.join(f"{x['name']}\t{x['F']}\t{x['R']}\n" for x in r))
for role in ['target','background']:
 f=v/(role+'.fasta')
 if not f.exists():f.symlink_to(root/f'outputs/MiUrchin/analysis/{role}.fasta')
subprocess.run([str(root/'work/miurchin_mifish/verify/scanner'),str(v)],check=True)
