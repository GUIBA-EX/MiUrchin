from pathlib import Path
import csv,json,sys,collections,itertools,functools,math
import numpy as np
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Data.IUPACData import ambiguous_dna_values as I
root=Path(__file__).resolve().parents[2];p=Path(__file__).parent
sys.path.insert(0,str(root/'work/miurchin'));from scan_core import database
panel=json.loads((root/'work/miurchin_mifish/panel.json').read_text());w=np.array([r['weight'] for r in panel]);w/=w.sum();seq={r.id:str(r.seq).upper() for r in SeqIO.parse(root/'outputs/MiUrchin/analysis/target_aligned.fasta','fasta')};cols=[i for i,b in enumerate(seq['NC_001453.1']) if b!='-'];refs=database(root/'outputs/MiUrchin/analysis/background.fasta')[3]
allrows=[];data={};pooldirs=['same_locus','same_locus_common_panel']
for dirname in pooldirs:
 d=root/'work/miurchin'/dirname;ol={r['id']:r for r in json.loads((d/'oligos.json').read_text())};pairs=json.loads((d/'rank_pair_order.json').read_text());risks=list(csv.DictReader((d/'fast_risks.tsv').open(),delimiter='\t'));cache={}
 def states(key):
  if key in cache:return cache[key]
  r=ol[key];q=r['sequence'];left,right=int(r['left']),int(r['right']);slices=[seq[x['accession']][cols[max(0,left-5)]:cols[right+4]+1].replace('-','') for x in panel]
  if r['side']=='R':slices=[str(Seq(s).reverse_complement()) for s in slices]
  cv=[];ex=[]
  for s in slices:
   coverage=False;exact=False
   for i in range(len(s)-len(q)+1):
    t=s[i:i+len(q)]
    if not set(t)<=set('ACGT'):continue
    mm=[b not in I[a] for a,b in zip(q,t)];coverage|=sum(mm)<=2 and not any(mm[-3:]);exact|=not any(mm)
   cv.append(coverage);ex.append(exact)
  cache[key]=(np.array(cv),np.array(ex));return cache[key]
 @functools.lru_cache(None)
 def bg(key):return json.loads((d/'background_hits'/f'{key}.json').read_text())['hits']
 def background(a,b,model,count):
  if count==0:return set()
  fh,rh=bg(a)[model],bg(b)[model];limit=3 if model=='WC' else 2;found=set()
  for k in fh.keys()&rh.keys():
   if any(not fa and not ra and fm<=limit and rm<=limit and 0<=rp-fp-len(ol[a]['sequence'])<=1000 for fp,fm,f5,fa in fh[k] for rp,rm,r5,ra in rh[k]):found.update(refs[int(k)]['accessions'])
  assert len(found)==count,(dirname,a,b,model,count,len(found))
  return found
 for r,risk in zip(pairs,risks):
  if r['band'] not in ['MiUrchin-XS','MiUrchin-S'] or int(risk['WC_le3'])>5 or int(risk['GT_le2'])>5 or float(r['tm_delta'])>5:continue
  f,re=r['F_id'],r['R_id'];cv=states(f)[0]&states(re)[0];ex=states(f)[1]&states(re)[1]
  if w@cv<.2:continue
  key=(r['F'],r['R']);a=background(f,re,'WC',int(risk['WC_le3']));b=background(f,re,'GT',int(risk['GT_le2']))
  data[key]=dict(region='S' if r['band']=='MiUrchin-XS' else 'M',F=r['F'],R=r['R'],source=dirname,F_id=f,R_id=re,coverage=float(w@cv),exact=float(w@ex),cv=cv.tolist(),ex=ex.tolist(),WC3=sorted(a),GT2=sorted(b),degeneracy_F=math.prod(len(I[x]) for x in r['F']),degeneracy_R=math.prod(len(I[x]) for x in r['R']))
 print(dirname,len(data),flush=True)
(p/'pool.json').write_text(json.dumps(list(data.values())))
for reg in ['S','M']:
 for chemistry in ['ordinary','degenerate']:
  rr=[r for r in data.values() if r['region']==reg and ((r['degeneracy_F']*r['degeneracy_R']>1)==(chemistry=='degenerate'))]
  print(reg,chemistry,len(rr),max([(r['coverage'],r['exact']) for r in rr],default=None),flush=True)
