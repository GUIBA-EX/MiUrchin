from pathlib import Path
import csv,json,re
p=Path(__file__).resolve().parents[1];d=p/'results/compact'
def rows(n):return list(csv.DictReader((d/n).open()))
r=rows('primer_pairs.csv');c=rows('comparison.csv');assert len(c)==8
assert {x['scheme'] for x in r}=={x['scheme'] for x in c}
for x in c:
 pp=[y for y in r if y['scheme']==x['scheme']];assert len(pp)==int(x['pairs']) and len(pp) in [1,2]
 assert int(x['WC3'])<=5 and int(x['GT2'])<=5
 assert 0<=float(x['exact_pct'])<=float(x['coverage_pct'])<=100+1e-8
 for y in pp:
  for side in ['F','R']:assert set(y[side])<=set('ACGT')
  assert abs(float(y['F_tm'])-float(y['R_tm']))<=5+1e-8
fasta={};key=None
for line in (d/'primers.fasta').read_text().splitlines():
 if line.startswith('>'):key=line[1:];fasta[key]=''
 else:fasta[key]+=line
assert len(fasta)==2*len(r)
for x in r:
 for side in ['F','R']:assert fasta[x['name']+'_'+side]==x[side]
assert all(x['background_pass'] for x in json.loads((d/'verification.json').read_text()))
for f in [p/'README.md',p/'README.zh-CN.md',*list((p/'docs').glob('*.md'))]:
 for link in re.findall(r'\]\(([^)]+)\)',f.read_text()):
  if not link.startswith(('http','#')):assert (f.parent/link.split('#')[0]).exists(),(f,link)
print('PASS: eight compact portfolios, sequences, counts, thresholds, metrics and document links')
