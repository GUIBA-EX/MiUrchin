from pathlib import Path
import csv,json,shutil
root=Path.cwd();p=root/'work/miurchin_mifish';repo=root/'outputs/MiUrchin';a=repo/'analysis'
tax={r['accession']:r for r in csv.DictReader((a/'target_taxonomy.tsv').open(),delimiter='\t')};panel={}
for r in csv.DictReader((a/'target_detail.tsv').open(),delimiter='\t'):
 if r['panel']=='common':panel[r['accession']]=dict(accession=r['accession'],organism=r['organism'],order=tax[r['accession']]['order'],weight=float(r['weight']))
(p/'panel.json').write_text(json.dumps(list(panel.values())))
for role in ['target','background']:shutil.copy2(a/(role+'.fasta'),p/(role+'.fasta'))
s=(root/'work/micucumber_mifish/discover.py').read_text();s=s.replace("work/micucumber_round2/optimization/target_aligned.fasta","outputs/MiUrchin/analysis/target_aligned.fasta").replace("panel=list(csv.DictReader((root/'outputs/MiCucumber/results/matching/panel.csv').open()))","panel=json.loads((out/'panel.json').read_text())").replace('AB525437.1','NC_001453.1').replace("[('S',954,981),('M',924,945),('L',843,870),('XL',774,799)]","[('S',185,206),('M',1033,1052),('L',937,960),('XL',529,548)]").replace("('R',1133)","('R',{'S':349,'M':1239,'L':1239,'XL':941}[region])")
(p/'discover.py').write_text(s)
s=(root/'work/micucumber_mifish/specific/prepare.py').read_text().replace('work/micucumber_round2/optimization/target_aligned.fasta','outputs/MiUrchin/analysis/target_aligned.fasta').replace('AB525437.1','NC_001453.1');(p/'specific/prepare.py').write_text(s)
for name in ['scan_sites.cpp','optimize_pairs.py']:shutil.copy2(root/'work/micucumber_mifish/specific'/name,p/'specific'/name)
(p/'deps').symlink_to(root/'work/micucumber_mifish/deps',target_is_directory=True)
print(len(panel),'common haplotypes')
