from pathlib import Path
import csv,json,sys,collections
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p/'deps'));import primer3
rows=json.loads((p/'verify/selected.json').read_text());states=json.loads((p/'specific/oligo_states.json').read_text());panel=json.loads((p/'panel.json').read_text());hits=collections.defaultdict(set)
for r in csv.DictReader((p/'verify/independent_hits.tsv').open(),delimiter='\t'):
 if r['role']=='target':
  for flag in ['le2last3','exact']:
   if r[flag]=='1':hits[r['name'],flag].add(r['accession'])
checks=[];thermal=[];kw=dict(mv_conc=50,dv_conc=1.5,dntp_conc=.6,dna_conc=200)
for r in rows:
 f,q=r['F'],r['R'];vals=[primer3.calc_hairpin(x,**kw).tm for x in [f,q]]+[primer3.calc_homodimer(x,**kw).tm for x in [f,q]]+[primer3.calc_heterodimer(f,q,**kw).tm]
 thermal.append(dict(name=r['name'],max_structure_tm=max(vals),delta_tm=abs(primer3.calc_tm(f,**kw)-primer3.calc_tm(q,**kw))))
 for mode,flag in [('coverage','le2last3'),('exact','exact')]:
  for i,item in enumerate(panel):
   predicted=states[r['F_id']][mode][i] and states[r['R_id']][mode][i];scanned=item['accession'] in hits[r['name'],flag]
   checks.append(dict(name=r['name'],accession=item['accession'],mode=mode,aligned=predicted,full_scan=scanned,agree=predicted==scanned))
with (p/'release/thermal.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(thermal[0]),lineterminator='\n');w.writeheader();w.writerows(thermal)
assert all(r['max_structure_tm']<55 and r['delta_tm']<=5 for r in thermal)
summary=dict(checks=len(checks),disagreements=sum(not x['agree'] for x in checks),thermal_pass=True,scope='Aligned binding-window predictions vs independent full-sequence scan. Published metrics use full scan.')
(p/'release/independent_validation.json').write_text(json.dumps(summary,indent=2));(p/'release/scan_disagreements.json').write_text(json.dumps([x for x in checks if not x['agree']],indent=2));print(summary)
