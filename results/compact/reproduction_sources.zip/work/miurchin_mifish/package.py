from pathlib import Path
import csv,json,shutil,hashlib,subprocess,zipfile
root=Path(__file__).resolve().parents[2];p=Path(__file__).resolve().parent;repo=root/'outputs/MiUrchin';src=p/'release';dest=repo/'results/compact';dest.mkdir(exist_ok=True);scripts=repo/'scripts';scripts.mkdir(exist_ok=True)
for f in src.iterdir():
 if f.suffix=='.svg':shutil.copy2(f,repo/'figures'/f.name)
 else:shutil.copy2(f,dest/f.name)
rows=list(csv.DictReader((src/'comparison.csv').open()))
for zh in [False,True]:
 fname='README.zh-CN.md' if zh else 'README.md';old=repo/fname;archive=repo/'docs'/('BASELINE.zh-CN.md' if zh else 'BASELINE.md')
 if not archive.exists():
  s=old.read_text();import re
  s=re.sub(r'\]\((?!http|#)([^)]+)\)',lambda m:'](../'+m[1]+')',s);archive.write_text(s)
 title='# MiUrchin\n\n'+('[English](README.md) · [方法](docs/METHODS.zh-CN.md) · [复现](docs/REPRODUCIBILITY.md)' if zh else '[中文](README.zh-CN.md) · [Methods](docs/METHODS.md) · [Reproduction](docs/REPRODUCIBILITY.md)')
 intro=('海胆线粒体16S引物：参考MiFish的逐位点共识设计，在四个长度窗口搜索普通引物，并精简为单对与两对独立PCR方案。' if zh else 'Mitochondrial 16S primers for sea urchins. MiFish-inspired base-level consensus design searches four length windows and selects one-pair and two-pair separate-PCR options.')
 naming=('长度依次为S、M、L、XL；单对直接使用长度名称，两对的具体配对加A、B，例如SA、SB，合用结果记为SA+SB。全部序列按5′→3′书写。' if zh else 'Lengths are S, M, L and XL. A single pair uses the region name; the two-pair components use A and B, for example SA and SB, with union metrics labelled SA+SB. All sequences are 5′→3′.')
 text=title+'\n\n'+intro+'\n\n'+naming+'\n\n'+('## 方案比较' if zh else '## Portfolio comparison')+'\n\n'
 text+=('共同面板为49个分类名称标签、80个标签内单倍型，采用标签等权及标签内单倍型等权。背景为6,045条记录。' if zh else 'The common panel contains 49 taxonomic name labels and 80 within-label haplotypes, weighted equally by label and then by haplotype within label. The background contains 6,045 records.')+'\n\n| Scheme | Pairs | Coverage | Exact | Product bp | WC≤3 | GT≤2 | WC≤4 |\n|---|---:|---:|---:|---:|---:|---:|---:|\n'
 for r in rows:text+=f"| {r['scheme']} | {r['pairs']} | {float(r['coverage_pct']):.2f}% | {float(r['exact_pct']):.2f}% | {r['product_min']}–{r['product_max']} | {r['WC3']} | {r['GT2']} | {r['WC4']} |\n"
 text+='\n'+('覆盖允许每条引物最多2处错配，但3′末端3 nt必须完全匹配；完全匹配要求正反引物均0错配。GT为G–T容忍敏感性模型，单独统计，不算严格完全匹配。背景数字为accession数，非实验扩增比例。' if zh else 'Coverage permits up to two mismatches per primer with the terminal three bases exactly matched; exact matching requires zero mismatches in both primers. GT is a separate G–T tolerance sensitivity model, not strict exact matching. Background values count accessions, not experimental amplification fractions.')
 text+='\n\n'+('## 序列与证据' if zh else '## Sequences and evidence')+'\n\n[Primer pairs](results/compact/primer_pairs.csv) · [FASTA](results/compact/primers.fasta) · [Comparison](results/compact/comparison.csv) · [Missed references](results/compact/missed_references.csv) · [Verification](results/compact/verification.json)\n\n'
 text+=('## 碱基匹配图\n\n显示实际碱基而非命中热图。蓝色表示相同、橙色表示错配、紫色表示可能的G–T配对，方框标明3′末端3 nt。引物及同向参考按5′→3′展示；反向引物对应参考已反向互补。静态图展示A/B方案及每目加权频率最高的结合序列；完整页面包含单对方案和目内所有不同结合序列。\n\n' if zh else '## Base matching\n\nActual bases are shown: blue = match, orange = mismatch, purple = possible G–T pairing; boxes mark the terminal three bases. Primers and same-sense references are 5′→3′; reverse-reference sites are reverse-complemented. Static figures show A/B pairs and the most frequent weighted binding sequence in each order. The complete page includes single-pair options and all distinct binding sequences within each order.\n\n')
 for reg in ['S','M','L','XL']:
  if (repo/'figures'/f'base_matching_{reg}.svg').exists():text+=f'![{reg} base matching](figures/base_matching_{reg}.svg)\n\n'
 text+='[Full base alignment](results/compact/base_matching.html)\n\n'
 text+=('## 适用范围\n\n本轮优化共同面板，结果来自冻结参考库的计算筛选与全序列复核，尚无湿实验验证。区域面板的分类群组成不同，不能将共同面板结果视为全部海胆的覆盖。两对方案为独立PCR结果并集，尚未验证同管混合体系。\n\n' if zh else '## Evaluation scope\n\nThis round optimizes the common panel using frozen references and full-sequence revalidation. Wet-lab validation is pending. Region panels differ in taxonomic composition; common-panel performance is not class-wide coverage. Two-pair metrics represent separate PCR unions, not a validated multiplex mixture.\n\n')
 text+=f'[Baseline analysis](docs/{archive.name}) · [Reproduction](docs/REPRODUCIBILITY.md)\n\n## Copyright\n\nCopyright © 2026 Fei Xia (GUIBA-EX). All rights reserved. [Terms / 使用声明](COPYRIGHT.md).\n'
 old.write_text(text)
for zh in [False,True]:
 name='METHODS.zh-CN.md' if zh else 'METHODS.md'
 text=('# 方法\n\n[English](METHODS.md)\n\n' if zh else '# Methods\n\n[中文](METHODS.zh-CN.md)\n\n')
 text+=('以NC_001453.1的16S为坐标参考，在四个窗口起点±15 nt内搜索20–30 nt引物。按共同面板碱基频率构造WC及G–T相容共识，并加入每窗口最常见的3条真实结合序列；过滤GC 35–65%及连续6个相同碱基。目标3′末端3 nt必须完全匹配。\n\nPrimer3条件：单价盐50 mM、Mg²⁺ 1.5 mM、dNTP 0.6 mM、每条引物200 nM。单引物发卡/同源二聚体及配对异源二聚体Tm<55°C，正反Tm差≤5°C。\n\n背景全序列双链扫描要求正确方向及0–1,000 nt内部距离。筛选每套组合WC≤3及GT≤2各≤5条记录。优先最大化共同面板覆盖，再最大化完全匹配；穷举通过约束的单对和两对，并合并相同命中状态以减少重复计算。\n\n最后使用独立完整配对扫描复核目标产物（150–500 bp、内部≥50 nt）及背景。搜索范围有限，不代表全基因组全局最优。原始完整参考、旧分析及复核证据保留在analysis/。' if zh else 'Using extracted 16S NC_001453.1 coordinates, search 20–30 nt primers within ±15 nt of four seed starts. Generate WC and G–T-compatible consensus sequences from common-panel base frequencies, adding the three most frequent observed binding sequences per window. Filter to 35–65% GC and exclude six-base homopolymers. Target terminal three bases must match exactly.\n\nPrimer3: 50 mM monovalent salt, 1.5 mM Mg²⁺, 0.6 mM dNTP and 200 nM per oligo. Hairpin, homodimer and pair heterodimer Tm must be below 55°C; F/R Tm difference ≤5°C.\n\nBackground scans cover both strands, correct orientation and 0–1,000 nt internal distance. Each portfolio permits ≤5 WC≤3 and ≤5 GT≤2 accessions. Maximize common-panel coverage, then exact matching. Enumerate feasible single and two-pair states, collapsing identical target/background states.\n\nIndependently rescan complete paired products: target length 150–500 bp with ≥50 nt internal sequence, and background as above. The bounded search does not establish a genome-wide optimum. Frozen references and baseline evidence remain under analysis/.')
 text+='\n\n[Miya et al. 2015](https://doi.org/10.1098/rsos.150088)\n';(repo/'docs'/name).write_text(text)
print('documentation prepared')
