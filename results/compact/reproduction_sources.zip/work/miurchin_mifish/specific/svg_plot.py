exec((__import__('pathlib').Path(__file__).parent/'publish.py').read_text())
from xml.sax.saxutils import escape
for reg in ['S','M','L','XL']:
 rr=[r for r in selected if r['region']==reg and r['option']==2];elements=[];y=90
 for r in rr:
  for side in ['F','R']:
   ol=oligos[r[side+'_id']];q=r[side];a,b=int(ol['start']),int(ol['end']);groups={}
   for item in panel:
    s=seq[item['accession']][cols[a-1]:cols[b-1]+1]
    if side=='R':s=str(Seq(s).reverse_complement())
    groups.setdefault(item['order'],{}).setdefault(s,[]).append(item)
   records=[('Primer 5′ → 3′',q)]
   for order,g in sorted(groups.items()):
    s,items=max(g.items(),key=lambda kv:sum(float(x['weight']) for x in kv[1]));records.append((order+' / '+items[0]['accession'],s))
   elements.append(f'<text x="24" y="{y}" font-size="18">{reg}{chr(64+int(r["component"]))} / {side} — {a}–{b}</text>');y+=15
   for label,s in records:
    elements.append(f'<text x="24" y="{y+20}" font-size="13">{escape(label)}</text>')
    for i,ch in enumerate(s):
     c='#d7edf5' if len(s)==len(q) and ch==q[i] else '#e5d6fa' if len(s)==len(q) and (q[i],ch) in [('G','A'),('T','C')] else '#ffd3a3'
     x=390+22*i;elements.append(f'<rect x="{x}" y="{y}" width="21" height="28" fill="{c}"/><text x="{x+6}" y="{y+20}" font-family="monospace" font-size="16">{ch}</text>')
    y+=30
   elements.append(f'<rect x="{390+22*(len(q)-3)}" y="{y-30*len(records)}" width="66" height="{30*len(records)}" fill="none" stroke="#173647" stroke-width="2"/>');y+=45
 (out/f'base_matching_{reg}.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="{y}" viewBox="0 0 1200 {y}"><rect width="100%" height="100%" rx="18" fill="#f7fafc"/><g font-family="Arial" fill="#173647"><text x="24" y="30" font-size="23">MiUrchin {reg} | Primer–template alignment</text><text x="24" y="55" font-size="13">Blue: match · Orange: mismatch · Purple: possible G–T · Box: terminal 3 nt · Most frequent sequence per order</text>'+''.join(elements)+'</g></svg>')
