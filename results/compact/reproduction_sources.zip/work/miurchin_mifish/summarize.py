from pathlib import Path
import csv,json,collections
p=Path(__file__).resolve().parent;v=p/'verify';out=p/'release';out.mkdir(exist_ok=True);rr=json.loads((v/'selected.json').read_text());panel=json.loads((p/'panel.json').read_text());weights={x['accession']:float(x['weight']) for x in panel};den=sum(weights.values());h=collections.defaultdict(set);sizes=collections.defaultdict(list)
for r in csv.DictReader((v/'independent_hits.tsv').open(),delimiter='\t'):
 for k in ['exact','le2last3','le2','le3','le4']:
  if r[k]=='1':h[r['name'],r['role'],r['model'],k].add(r['accession'])
 if r['role']=='target' and r['accession'] in weights and r['sizes']:sizes[r['name']]+=[int(x) for x in r['sizes'].split(',')]
def write(n,rows):
 with (out/n).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
comp=[];missed=[];checks=[]
for scheme in dict.fromkeys(r['scheme'] for r in rr):
 pairs=[r for r in rr if r['scheme']==scheme];ns=[r['name'] for r in pairs]
 def union(role,model,k):return set().union(*(h[n,role,model,k] for n in ns))
 cv=union('target','WC','le2last3');ex=union('target','WC','exact');bg=union('background','WC','le3');gt=union('background','GT','le2');sz=sum([sizes[n] for n in ns],[])
 cov=100*sum(weights.get(a,0) for a in cv)/den;exact=100*sum(weights.get(a,0) for a in ex)/den
 comp.append(dict(scheme=scheme,region=pairs[0]['region'],pairs=len(ns),coverage_pct=cov,exact_pct=exact,WC3=len(bg),GT2=len(gt),WC4=len(union('background','WC','le4')),product_min=min(sz) if sz else '',product_max=max(sz) if sz else ''))
 checks.append(dict(scheme=scheme,aligned_coverage=100*pairs[0]['union_coverage'],scan_coverage=cov,aligned_exact=100*pairs[0]['union_exact'],scan_exact=exact,background_pass=len(bg)<=5 and len(gt)<=5))
 for x in panel:
  if x['accession'] not in cv:missed.append(dict(scheme=scheme,**x))
write('comparison.csv',comp);write('primer_pairs.csv',[{k:r[k] for k in ['scheme','region','name','F','R','F_id','R_id','F_tm','R_tm']} for r in rr]);write('missed_references.csv',missed)
(out/'primers.fasta').write_text(''.join(f">{r['name']}_{d}\n{r[d]}\n" for r in rr for d in ['F','R']))
(out/'verification.json').write_text(json.dumps(checks,indent=2));print(json.dumps(comp,indent=2));assert all(x['background_pass'] for x in checks)
