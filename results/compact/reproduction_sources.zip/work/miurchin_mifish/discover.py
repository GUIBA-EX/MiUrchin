from pathlib import Path
import csv,json,collections
import numpy as np
from Bio import SeqIO
from Bio.Seq import Seq
root=Path(__file__).resolve().parents[2];out=Path(__file__).parent
seq={r.id:str(r.seq).upper() for r in SeqIO.parse(root/'outputs/MiUrchin/analysis/target_aligned.fasta','fasta')}
panel=json.loads((out/'panel.json').read_text())
panel=[r for r in panel if r['order']!='Apodida']
ref=seq['NC_001453.1'];cols=[i for i,b in enumerate(ref) if b!='-'];bases='ACGT'
weights=np.array([float(r['weight']) for r in panel]);weights/=weights.sum()
# Aligned windows retain internal gaps: no deletion of reference-specific indels.
rows=[];states={}
for region,start,end in [('S',185,206),('M',1033,1052),('L',937,960),('XL',529,548)]:
 for side,anchor in [('F',start),('R',{'S':349,'M':1239,'L':1239,'XL':941}[region])]:
  seen=set()
  for shift in range(-15,16):
   for length in range(20,31):
    a=anchor+shift;b=a+length-1
    windows=[seq[r['accession']][cols[a-1]:cols[b-1]+1] for r in panel]
    if side=='R':windows=[str(Seq(s).reverse_complement()) for s in windows]
    # Candidate consensus uses gap-free windows; missing windows remain failures in scores.
    good=np.array([len(s)==length and set(s)<=set(bases) for s in windows])
    if weights[good].sum()<.5:continue
    counts=np.array([[sum(weights[k] for k,s in enumerate(windows) if good[k] and s[j]==base) for base in bases] for j in range(length)])
    for model in ['WC','GT']:
     utility=counts.copy()
     # Same-sense target representation: primer G tolerates target A, T tolerates C.
     if model=='GT':utility[:,2]+=counts[:,0];utility[:,3]+=counts[:,1]
     q=''.join(bases[i] for i in utility.argmax(axis=1))
     if q in seen:continue
     seen.add(q);gc=sum(c in 'GC' for c in q)/length
     if not .4<=gc<=.6 or any(c*5 in q for c in bases):continue
     cov=[];gt=[];exact=[]
     for ok,s in zip(good,windows):
      if not ok:cov.append(False);gt.append(False);exact.append(False);continue
      mm=[x!=y for x,y in zip(q,s)];gm=[x!=y and (x,y) not in [('G','A'),('T','C')] for x,y in zip(q,s)]
      exact.append(not any(mm));cov.append(sum(mm)<=2 and not any(mm[-3:]));gt.append(sum(gm)<=2 and not any(gm[-3:]))
     name=f'{region}_{side}_{len(rows):05d}'
     rows.append(dict(candidate=name,region=region,side=side,start=a,end=b,sequence=q,design_model=model,gc=gc,WC_coverage=100*float(weights@cov),exact=100*float(weights@exact),GT_coverage=100*float(weights@gt)))
     states[name]=dict(WC=cov,GT=gt,exact=exact)
with (out/'oligo_candidates.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(out/'oligo_states.json').write_text(json.dumps(states))
(out/'panel.json').write_text(json.dumps(panel))
print('Candidates',len(rows))
for region in ['S','M','L','XL']:
 for side in ['F','R']:
  rr=[r for r in rows if r['region']==region and r['side']==side]
  print(region,side,max(rr,key=lambda r:r['WC_coverage']))
