from pathlib import Path
import csv,json,subprocess
p=Path(__file__).resolve().parent;v=p/'verify';v.mkdir(exist_ok=True);selection=json.loads((p/'specific/selection.json').read_text());rows=[]
for reg in ['S','M','L','XL']:
 for count in [1,2]:
  rr=[r for r in selection if r['region']==reg and r['option']==count]
  for i,r in enumerate(rr):
   name=reg if count==1 else reg+chr(65+i);rows.append(dict(r,name=name,scheme=reg if count==1 else reg+'A+'+reg+'B'))
(v/'selected.json').write_text(json.dumps(rows,indent=2));(v/'independent_primers.tsv').write_text(''.join(f"{r['name']}\t{r['F']}\t{r['R']}\n" for r in rows))
for role in ['target','background']:
 f=v/(role+'.fasta')
 if not f.exists():f.symlink_to(p/(role+'.fasta'))
src=p.parent/'micucumber_nondegenerate/independent_scan.cpp';subprocess.run(['c++','-O3','-std=c++17',str(src),'-o',str(v/'scanner')],check=True);subprocess.run([str(v/'scanner'),str(v)],check=True)
