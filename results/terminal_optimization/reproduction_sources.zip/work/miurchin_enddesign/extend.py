from pathlib import Path
import json,csv,sys,itertools,collections,functools
import numpy as np
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Data.IUPACData import ambiguous_dna_values as I
p=Path(__file__).resolve().parent;root=p.parents[1]
sys.path.insert(0,str(root/'work/micucumber_mifish/deps'));import primer3
old=json.loads((root/'work/miurchin_sm/selected.json').read_text())
seq={r.id:str(r.seq).upper() for r in SeqIO.parse(root/'outputs/MiUrchin/analysis/target_aligned.fasta','fasta')};cols=[i for i,b in enumerate(seq['NC_001453.1']) if b!='-'];panel=json.loads((root/'work/miurchin_mifish/panel.json').read_text());w=np.array([x['weight'] for x in panel]);w/=w.sum()
meta={src:{r['id']:r for r in json.loads((root/'work/miurchin'/src/'oligos.json').read_text())} for src in ['same_locus','same_locus_common_panel']};shift={r['name']:r for r in csv.DictReader((root/'work/miurchin_mifish/specific/oligos.csv').open())};kw=dict(mv_conc=50,dv_conc=1.5,dntp_conc=.6,dna_conc=200)
@functools.lru_cache(None)
def expand(q):return list(map(''.join,itertools.product(*(I[c] for c in q))))
def good(q):return 18<=len(q)<=32 and all(len(set(s[-3:]))>1 and 1<=sum(c in 'GC' for c in s[-5:])<=4 for s in expand(q))
@functools.lru_cache(None)
def tm(q):return [primer3.calc_tm(s,**kw) for s in expand(q)]
ol={};seen={};pairs={}
def variants(r,side):
 m=shift[r[side+'_id']] if r['source']=='mifish_shifted' else meta[r['source']][r[side+'_id']]
 a,b=(int(m['start'])-1,int(m['end'])) if r['source']=='mifish_shifted' else (int(m['left']),int(m['right']))
 q=r[side];variants=[]
 for d in range(-6,7):
  aa=a+(d if side=='R' else 0);bb=b-(d if side=='F' else 0)
  if d>=0:qs=[q[:-d] if d else q]
  else:
   flanks=collections.Counter()
   for x,weight in zip(panel,w):
    s=seq[x['accession']][cols[aa]:cols[bb-1]+1].replace('-','')
    if side=='R':s=str(Seq(s).reverse_complement())
    if len(s)==len(q)-d and set(s)<=set('ACGT'):flanks[s[len(q):]]+=weight
   qs=[q+f for f,_ in flanks.most_common(3)]
  repaired=[]
  for candidate in qs:
   if any(any(c*5 in v for c in 'ACGT') for v in expand(candidate)):
    for i,c in enumerate(candidate):
     if len(I[c])>1:
      for b0 in I[c]:
       q0=candidate[:i]+b0+candidate[i+1:]
       if not any(any(c0*5 in v for c0 in 'ACGT') for v in expand(q0)):repaired.append(q0)
   else:repaired.append(candidate)
  for new in repaired:
   if not good(new):continue
   key=(r['region'],side,new)
   if key not in seen:
    name=f'E{len(ol):04d}';seen[key]=name;cv=[];ex=[]
    for x in panel:
     s=seq[x['accession']][cols[max(0,aa-5)]:cols[bb+4]+1].replace('-','')
     if side=='R':s=str(Seq(s).reverse_complement())
     hits=[]
     for i in range(len(s)-len(new)+1):
      t=s[i:i+len(new)]
      if not set(t)<=set('ACGT'):continue
      mm=[c not in I[n] for n,c in zip(new,t)];hits.append((sum(mm),sum(mm[-3:])))
     cv.append(any(n<=2 and z==0 for n,z in hits));ex.append(any(n==0 for n,z in hits))
    ol[name]=dict(id=name,region=r['region'],side=side,sequence=new,left=aa,right=bb,cv=cv,ex=ex)
   variants.append(seen[key])
 return list(dict.fromkeys(variants))
for r in old:
 fs=variants(r,'F');rs=variants(r,'R')
 for f,re in itertools.product(fs,rs):
  F=ol[f]['sequence'];R=ol[re]['sequence'];ft=tm(F);rt=tm(R)
  # Compare the midpoint of variant Tm ranges; full variant ranges are reported later.
  if abs((min(ft)+max(ft)-min(rt)-max(rt))/2)>5:continue
  cv=(np.array(ol[f]['cv'])&ol[re]['cv']).tolist();ex=(np.array(ol[f]['ex'])&ol[re]['ex']).tolist()
  if w@cv<.1:continue
  pairs[F,R]=dict(region=r['region'],F=F,R=R,F_id=f,R_id=re,source='terminal_adjustment',cv=cv,ex=ex,degeneracy_F=len(expand(F)),degeneracy_R=len(expand(R)))
(p/'extended_pairs.json').write_text(json.dumps(list(pairs.values())));(p/'extended_oligos.json').write_text(json.dumps(list(ol.values())))
d=p/'sites';d.mkdir(exist_ok=True);used={r[k+'_id'] for r in pairs.values() for k in ['F','R']};(d/'oligos.tsv').write_text(''.join(f"{n} {ol[n]['side']} {ol[n]['sequence']}\n" for n in sorted(used)))
f=p/'background.fasta'
if not f.exists():f.symlink_to(root/'outputs/MiUrchin/analysis/background.fasta')
print('pairs',len(pairs),'oligos',len(ol),'used',len(used),flush=True)
