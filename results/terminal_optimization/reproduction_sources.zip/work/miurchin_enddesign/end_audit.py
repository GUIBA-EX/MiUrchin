from pathlib import Path
import json,csv,itertools,sys,collections
from Bio.Seq import Seq
from Bio.Data.IUPACData import ambiguous_dna_values as I
p=Path(__file__).resolve().parent;root=p.parents[1];sys.path.insert(0,str(root/'work/micucumber_mifish/deps'));import primer3
rows=json.loads((p/'selected_strict.json').read_text());out=p/'release';out.mkdir(exist_ok=True)
def expand(q):return list(map(''.join,itertools.product(*(I[c] for c in q))))
def audit(name,side,q,stage):
 vs=expand(q);runs=[max(len(list(g)) for _,g in itertools.groupby(s)) for s in vs];gc5=[sum(c in 'GC' for c in s[-5:]) for s in vs];gc3=[sum(c in 'GC' for c in s[-3:]) for s in vs];ends=[len(list(itertools.takewhile(lambda c:c==s[-1],s[::-1]))) for s in vs]
 dg=[primer3.calc_end_stability(s[-5:],str(Seq(s[-5:]).reverse_complement()),mv_conc=50,dv_conc=1.5,dntp_conc=.6,dna_conc=200,temp_c=37).dg/1000 for s in vs]
 passed=max(runs)<=4 and max(ends)<=2 and min(gc3)>=1 and min(gc5)>=1 and max(gc5)<=4
 return dict(stage=stage,name=name,side=side,sequence=q,variants=len(vs),terminal_5=q[-5:],GC_last3_min=min(gc3),GC_last5_min=min(gc5),GC_last5_max=max(gc5),terminal_run_max=max(ends),homopolymer_max=max(runs),end5_dG37_min_kcal_mol=min(dg),end5_dG37_max_kcal_mol=max(dg),passes_terminal_rules=passed)
rr=[]
for r in {x['name']:x for x in rows}.values():
 for side in ['F','R']:rr.append(audit(r['name'],side,r[side],'current'))
assert all(x['passes_terminal_rules'] for x in rr)
# A frozen input is preferred on subsequent reproduction.
frozen=p/'previous_pairs.csv'
if frozen.exists():old=list(csv.DictReader(frozen.open()))
else:
 old=list(csv.DictReader((root/'outputs/MiUrchin/results/current/primer_pairs.csv').open()))
 with frozen.open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(old[0]),lineterminator='\n');w.writeheader();w.writerows(old)
for r in {x['name']:x for x in old}.values():
 for side in ['F','R']:rr.append(audit(r['name'],side,r[side],'previous'))
with (out/'terminal_audit.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rr[0]),lineterminator='\n');w.writeheader();w.writerows(rr)
print('current oligos',sum(x['stage']=='current' for x in rr),'all pass; previous failures',sum(x['stage']=='previous' and not x['passes_terminal_rules'] for x in rr))
