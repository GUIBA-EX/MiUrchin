from pathlib import Path
import json,csv,collections
p=Path(__file__).resolve().parent;root=p.parents[1];out=p/'release';out.mkdir(exist_ok=True);rr=json.loads((p/'selected_strict.json').read_text());panel=json.loads((root/'work/miurchin_mifish/panel.json').read_text());w={x['accession']:float(x['weight']) for x in panel};h=collections.defaultdict(set);sizes=collections.defaultdict(list)
for r in csv.DictReader((p/'verify/independent_hits.tsv').open(),delimiter='\t'):
 for k in ['exact','le2last3','le2','le3','le4']:
  if r[k]=='1':h[r['name'],r['role'],r['model'],k].add(r['accession'])
 if r['role']=='target' and r['accession'] in w and r['sizes']:sizes[r['name']]+=[int(x) for x in r['sizes'].split(',')]
comp=[];miss=[];checks=[]
for scheme in dict.fromkeys(x['scheme'] for x in rr):
 pp=[x for x in rr if x['scheme']==scheme];names=[x['name'] for x in pp]
 def union(role,model,k):return set().union(*(h[n,role,model,k] for n in names))
 cv=union('target','WC','le2last3');ex=union('target','WC','exact');sz=sum([sizes[n] for n in names],[])
 row=dict(scheme=scheme,region=pp[0]['region'],chemistry=pp[0]['chemistry'],pairs=len(pp),coverage_pct=100*sum(w.get(a,0) for a in cv)/sum(w.values()),exact_pct=100*sum(w.get(a,0) for a in ex)/sum(w.values()),WC3=len(union('background','WC','le3')),GT2=len(union('background','GT','le2')),WC4=len(union('background','WC','le4')),product_min=min(sz),product_max=max(sz));assert row['WC3']<=({'XLD':50}.get(scheme,5)) and row['GT2']<=({'XLD':50}.get(scheme,5));comp.append(row)
 for x in panel:
  if x['accession'] not in cv:miss.append(dict(scheme=scheme,**x))
for x in rr:
 for mode,flag in [('cv','le2last3'),('ex','exact')]:
  for i,a in enumerate(panel):checks.append(dict(name=x['name'],mode=mode,accession=a['accession'],prediction=x[mode][i],full_scan=a['accession'] in h[x['name'],'target','WC',flag]))
def write(n,rs):
 with (out/n).open('w') as f:
  wr=csv.DictWriter(f,fieldnames=list(rs[0]),lineterminator='\n');wr.writeheader();wr.writerows(rs)
write('comparison.csv',comp);write('primer_pairs.csv',[{k:x[k] for k in ['scheme','region','name','F','R','source','F_id','R_id','degeneracy_F','degeneracy_R']} for x in rr]);write('missed_references.csv',miss);write('thermal.csv',[dict(name=x['name'],**t) for x in rr for t in x['thermal']])
(out/'primers.fasta').write_text(''.join(f">{x['name']}_{side}\n{x[side]}\n" for x in {a['name']:a for a in rr}.values() for side in ['F','R']));bad=[x for x in checks if x['prediction']!=x['full_scan']];(out/'verification.json').write_text(json.dumps(dict(checks=len(checks),disagreements=len(bad),details=bad),indent=2));print(json.dumps(comp,indent=2));print('disagreements',len(bad));assert not bad
background_checks=[]
for x in rr:
 for model,col,flag in [('WC','WC3','le3'),('GT','GT2','le2')]:
  background_checks.append(dict(name=x['name'],model=model,agree=set(x[col])==h[x['name'],'background',model,flag]))
assert all(x['agree'] for x in background_checks)
(out/'verification.json').write_text(json.dumps(dict(checks=len(checks),disagreements=len(bad),details=bad,background_checks=len(background_checks),background_disagreements=sum(not x['agree'] for x in background_checks)),indent=2))
