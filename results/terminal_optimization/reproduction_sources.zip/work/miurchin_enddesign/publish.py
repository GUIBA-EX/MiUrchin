from pathlib import Path
import csv,json,shutil,zipfile,subprocess
p=Path(__file__).resolve().parent;root=p.parents[1];repo=root/'outputs/MiUrchin';dest=repo/'results/terminal_optimization';dest.mkdir(exist_ok=True);cur=repo/'results/current'
def read(f):return list(csv.DictReader(f.open()))
def write(f,rows):
 with f.open('w') as h:
  w=csv.DictWriter(h,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
old=read(dest/'previous_comparison.csv') if (dest/'previous_comparison.csv').exists() else read(cur/'comparison.csv');comp=read(p/'release/comparison.csv');pairs=read(p/'release/primer_pairs.csv')
for f in (p/'release').iterdir():
 shutil.copy2(f,dest/f.name)
 if f.suffix=='.svg':shutil.copy2(f,repo/'figures'/f.name)
for src,name in [(p/'verify/independent_hits.tsv','independent_hits.tsv'),(p/'audit_strict.json','search_audit.json'),(p/'selected_strict.json','selection.json')]:shutil.copy2(src,dest/name)
write(dest/'previous_comparison.csv',old);write(dest/'previous_pairs.csv',read(p/'previous_pairs.csv'))
fields=['scheme','region','name','F','R','degeneracy_F','degeneracy_R'];write(cur/'primer_pairs.csv',[{k:r[k] for k in fields} for r in pairs]);write(cur/'comparison.csv',comp);shutil.copy2(p/'release/primers.fasta',cur/'primers.fasta');shutil.copy2(p/'release/binding_positions.csv',cur/'binding_positions.csv')
for zh in [False,True]:
 f=repo/('README.zh-CN.md' if zh else 'README.md');s=subprocess.check_output(['git','show','HEAD:'+f.name],cwd=repo).decode();a=s.index('# MiUrchin');s=s[a:]
 caption=('图中徽标为SD、MD、L、XL在参考序列上的跨度，分别为188、228、343、440 bp；下图按同一线性比例展示所有当前配对。坐标为NC_001453.1提取的16S序列位置（1起始、去缺口），实际产物长度随类群变化。' if zh else 'Badge spans are 188, 228, 343 and 440 bp for SD, MD, L and XL on the reference. The map uses one linear scale for all current pairs. Coordinates are 1-based on extracted, ungapped NC_001453.1 16S; product lengths vary among taxa.')
 s='![MiUrchin overview](figures/MiUrchin_overview.png)\n\n![Current binding positions](figures/binding_positions.svg)\n\n'+caption+'\n\n'+s
 a=s.index('D仅用于' if zh else 'D identifies');b=s.index('## ',a)
 s=s[:a]+('D表示简并单对；SD+SB、MD+MB分别复用简并单对与一对普通补充引物。当前12套方案、18条配对记录，包含14个配对名、28条FASTA序列。\n\n' if zh else 'D identifies a degenerate pair. SD+SB and MD+MB reuse one degenerate pair and one ordinary supplement. There are 12 portfolios and 18 paired entries, with 14 pair names / 28 FASTA records.\n\n')+s[b:]
 a=s.index('| 方案 |' if zh else '| Scheme |');b=s.index('\n\n',a);table='| Scheme | Type | Pairs | Coverage | Exact | WC≤3 | GT≤2 | WC≤4 |\n|---|---|---:|---:|---:|---:|---:|---:|\n'
 for r in comp:table+=f"| {r['scheme']} | {r['chemistry']} | {r['pairs']} | {float(r['coverage_pct']):.2f}% | {float(r['exact_pct']):.2f}% | {r['WC3']} | {r['GT2']} | {r['WC4']} |\n"
 s=s[:a]+table.rstrip()+s[b:]
 a=s.index('**优先比较' if zh else '**Prioritize');b=s.index('## 序列与证据' if zh else '## Sequences and evidence',a)
 note=('**优先验证MD单对，必要时补充MB。** MD覆盖87.76%、完全匹配48.98%，F/R简并度为6/24；MD+MB为91.84%/55.10%。普通M单对为69.39%/16.33%，MA+MB为77.55%/22.45%。\n\nS仍有明显取舍：SD为67.35%/20.41%，SD+SB为77.55%/20.41%；普通S方案覆盖较低。SD的F/R简并度为12/12。末端修正降低了S的完全匹配率，不能将其描述为全面提升。\n\n全部实际变体均排除3′端三连同碱基，末端3位至少含1个G/C，末端5位含1–4个G/C，全序列同碱基连续长度不超过4。末端最后一位不强制为G/C。双浓度情景的结构Tm与正反Tm范围中点差均复核通过。详见[末端修正与验证](docs/TERMINAL_VALIDATION.md)。\n\n' if zh else '**Prioritize MD, adding MB when needed.** MD gives 87.76% coverage / 48.98% exact matching, with F/R degeneracy 6/24; MD+MB gives 91.84% / 55.10%. Ordinary M gives 69.39% / 16.33%, and MA+MB gives 77.55% / 22.45%.\n\nS retains a substantial trade-off: SD gives 67.35% / 20.41%, and SD+SB gives 77.55% / 20.41%; ordinary S coverage remains low. SD F/R degeneracy is 12/12. The terminal correction reduces S exact matching and is not an across-the-board improvement.\n\nEvery concrete variant excludes terminal homotriplets, has at least one G/C in the last three bases and 1–4 G/C in the last five, and has no homopolymer longer than four bases. A terminal G/C is not mandatory. Structure Tm and F/R Tm-range midpoint differences pass both concentration scenarios. See [terminal correction and verification](docs/TERMINAL_VALIDATION.md).\n\n')
 s=s[:a]+note+s[b:]
 a=s.index('[Primer pairs]') if not zh else -1
 # Update both language evidence sections as a whole.
 h='## 序列与证据' if zh else '## Sequences and evidence';a=s.index(h);b=s.index('## ',a+3)
 s=s[:a]+h+'\n\n[Primer pairs](results/current/primer_pairs.csv) · [FASTA](results/current/primers.fasta) · [Comparison](results/current/comparison.csv) · [Binding coordinates](results/current/binding_positions.csv) · [Missed references](results/terminal_optimization/missed_references.csv) · [Terminal audit](results/terminal_optimization/terminal_audit.csv) · [Verification](results/terminal_optimization/verification.json)\n\n'+s[b:]
 s=s.replace('[S/M full base alignment](results/sm_optimization/base_matching.html) · [L/XL full base alignment](results/compact/base_matching.html)','[Full base alignment](results/terminal_optimization/base_matching.html)')
 import re
 s=re.sub(r'\[[^\]]+\]\(results/sm_optimization/base_matching.html\)\s*·\s*\[[^\]]+\]\(results/compact/base_matching.html\)','[完整碱基匹配图](results/terminal_optimization/base_matching.html)',s)
 f.write_text(s)
print('published',len(comp),'portfolios',len(pairs),'paired rows')
