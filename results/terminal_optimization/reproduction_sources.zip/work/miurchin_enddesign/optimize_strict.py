from pathlib import Path
import json,sys,itertools,functools,math
import numpy as np
from Bio.Data.IUPACData import ambiguous_dna_values as I
p=Path(__file__).resolve().parent;root=p.parents[1];sys.path.insert(0,str(root/'work/micucumber_mifish/deps'));import primer3
rr=json.loads((p/'combined_pool.json').read_text());panel=json.loads((root/'work/miurchin_mifish/panel.json').read_text());w=np.array([x['weight'] for x in panel]);w/=w.sum()
# Include the previously screened shifted-window ordinary candidates with their original state vectors.
old=json.loads((root/'work/miurchin_mifish/specific/feasible.json').read_text());states=json.loads((root/'work/miurchin_mifish/specific/oligo_states.json').read_text())
for r in old:

 rr.append(dict(r,source='mifish_shifted',degeneracy_F=1,degeneracy_R=1,cv=(np.array(states[r['F_id']]['coverage'])&states[r['R_id']]['coverage']).tolist(),ex=(np.array(states[r['F_id']]['exact'])&states[r['R_id']]['exact']).tolist()))
kw=dict(mv_conc=50,dv_conc=1.5,dntp_conc=.6)
@functools.lru_cache(None)
def expand(q):return list(map(''.join,itertools.product(*(I[c] for c in q))))
@functools.lru_cache(None)
def single(q,c):return primer3.calc_tm(q,dna_conc=c,**kw),max(primer3.calc_hairpin(q,dna_conc=c,**kw).tm,primer3.calc_homodimer(q,dna_conc=c,**kw).tm)
@functools.lru_cache(None)
def hetero(a,b,c):return primer3.calc_heterodimer(a,b,dna_conc=c,**kw).tm
@functools.lru_cache(None)
def thermal(F,R):
 fs,rs=expand(F),expand(R);maxst=-100;report=[]
 for scenario in ['50_per_variant','200_per_direction']:
  fc=50 if scenario=='50_per_variant' else 200/len(fs);rc=50 if scenario=='50_per_variant' else 200/len(rs);ft=[single(q,fc) for q in fs];rt=[single(q,rc) for q in rs]
  st=max(v[1] for v in ft+rt)
  for a,b in itertools.combinations(fs,2):st=max(st,hetero(a,b,fc))
  for a,b in itertools.combinations(rs,2):st=max(st,hetero(a,b,rc))
  for a,b in itertools.product(fs,rs):st=max(st,hetero(a,b,max(fc,rc)))
  report.append(dict(scenario=scenario,F_tm_min=min(x[0] for x in ft),F_tm_max=max(x[0] for x in ft),R_tm_min=min(x[0] for x in rt),R_tm_max=max(x[0] for x in rt),structure_max=st));maxst=max(maxst,st)
 return maxst<55 and all(abs((t['F_tm_min']+t['F_tm_max']-t['R_tm_min']-t['R_tm_max'])/2)<=5 for t in report),report
@functools.lru_cache(None)
def terminal_ok(q):
 for s in expand(q):
  if any(c*5 in s for c in 'ACGT'):return False
  if len(set(s[-3:]))==1 or not any(c in 'GC' for c in s[-3:]):return False
  if not 1<=sum(c in 'GC' for c in s[-5:])<=4:return False
 return True
rr=[r for r in rr if terminal_ok(r['F']) and terminal_ok(r['R'])]
def bits(v):return sum(1<<i for i,b in enumerate(v) if b)
weight_masks={}
for i,weight in enumerate(w):weight_masks[float(weight)]=weight_masks.get(float(weight),0)|(1<<i)
def weighted(b):return sum(v*(b&m).bit_count() for v,m in weight_masks.items())
for r in rr:r['_cv']=bits(r['cv']);r['_ex']=bits(r['ex'])
selected=[];audit=[]
for reg in ['S','M','L','XL']:
 for chemistry in (['ordinary','degenerate'] if reg in ['S','M'] else ['ordinary']):
  for count in [1,2]:
   pool=[r for r in rr if r['region']==reg and (chemistry=='degenerate' or r['degeneracy_F']*r['degeneracy_R']==1)]
   # Same target/background state: keep lowest degeneracy to limit dilution.
   unique={}
   for r in pool:
    key=(tuple(r['cv']),tuple(r['ex']),tuple(r['WC3']),tuple(r['GT2']))
    if key not in unique or r['degeneracy_F']+r['degeneracy_R']<unique[key]['degeneracy_F']+unique[key]['degeneracy_R']:unique[key]=r
   pool=list(unique.values());failures=0
   def combinations(pool,count):
    if count==1:
     yield from itertools.combinations(pool,1);return
    cm=np.array([r['cv'] for r in pool],dtype=bool);em=np.array([r['ex'] for r in pool],dtype=bool)
    for i in range(len(pool)-1):
     c=(cm[i+1:]|cm[i])@w;e=(em[i+1:]|em[i])@w
     score=c if reg=='L' else c+e
     threshold=-1 if best is None else best[0]-1e-10
     for j in np.flatnonzero(score>=threshold):yield pool[i],pool[i+1+int(j)]
   while True:
    best=None;chosen=None
    for pp in combinations(pool,count):
     if chemistry=='degenerate':
      if sum(x['degeneracy_F']*x['degeneracy_R']>1 for x in pp)!=1:continue
      if count==2:
       single_pair=next(x for x in selected if x['region']==reg and x['chemistry']=='degenerate' and x['option']==1)
       if not any((x['F'],x['R'])==(single_pair['F'],single_pair['R']) for x in pp):continue
     wc=set().union(*(set(x['WC3']) for x in pp));gt=set().union(*(set(x['GT2']) for x in pp))
     if len(wc)>5 or len(gt)>5:continue
     cv=0;ex=0
     for x in pp:cv|=x['_cv'];ex|=x['_ex']
     coverage=weighted(cv);exact=weighted(ex)
     score=(round(coverage if reg=='L' else coverage+exact,12),round(coverage,12),round(exact,12),-sum(x['degeneracy_F']+x['degeneracy_R'] for x in pp),-len(wc)-len(gt))
     if best is None or score>best:best=score;chosen=pp
    if chosen is None:raise RuntimeError((reg,chemistry,count,'no viable candidates'))
    bad=[r for r in chosen if not thermal(r['F'],r['R'])[0]]
    if not bad:break
    failures+=len(bad);pool=[r for r in pool if all((r['F'],r['R'])!=(b['F'],b['R']) for b in bad)]
   stem=reg+('D' if chemistry=='degenerate' else '');scheme=stem if count==1 else stem+'A+'+stem+'B'
   for i,r in enumerate(chosen):selected.append(dict(r,scheme=scheme,name=stem if count==1 else stem+chr(65+i),option=count,chemistry=chemistry,union_coverage=best[1],union_exact=best[2],thermal=thermal(r['F'],r['R'])[1]))
   audit.append(dict(scheme=scheme,distinct_candidates=len(pool),thermal_rejections=failures,coverage=best[1],exact=best[2]));print(audit[-1],flush=True)
# Name each distinct pair consistently, reusing single/ordinary pair names.
for reg in ['S','M']:
 rows=[r for r in selected if r['region']==reg];known={}
 for r in rows:
  if r['chemistry']=='ordinary' or r['option']==1:known.setdefault((r['F'],r['R']),r['name'])
 extras=0
 for r in rows:
  if r['chemistry']=='degenerate' and r['option']==2:
   key=(r['F'],r['R'])
   if key not in known:
    extras+=1;known[key]=reg+('D' if r['degeneracy_F']*r['degeneracy_R']>1 else '')+chr(66+extras)
   r['name']=known[key];r['chemistry']='mixed' if r['degeneracy_F']*r['degeneracy_R']==1 else 'degenerate'
 group=[r for r in rows if r['option']==2 and r['chemistry']!='ordinary']
 if group:
  group.sort(key=lambda r:r['degeneracy_F']*r['degeneracy_R']==1)
  scheme='+'.join(r['name'] for r in group)
  chem='mixed' if any(r['degeneracy_F']*r['degeneracy_R']==1 for r in group) else 'degenerate'
  for r in group:r['scheme']=scheme;r['chemistry']=chem
(p/'selected_strict.json').write_text(json.dumps(selected,indent=2));(p/'audit_strict.json').write_text(json.dumps(audit,indent=2));print('DONE',flush=True)
