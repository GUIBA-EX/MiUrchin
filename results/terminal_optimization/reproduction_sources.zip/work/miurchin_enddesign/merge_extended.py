from pathlib import Path
import json,csv,collections
p=Path(__file__).resolve().parent
ol={x['id']:x for x in json.loads((p/'extended_oligos.json').read_text())};hits=collections.defaultdict(lambda:collections.defaultdict(list))
for name,acc,ori,gt,pos,mm,last in csv.reader((p/'sites/background_sites.tsv').open(),delimiter='\t'):
 hits[name,int(gt)][acc,int(ori)].append((int(pos),int(mm)))
rows=[]
for r in json.loads((p/'extended_pairs.json').read_text()):
 for gt,limit,col in [(0,3,'WC3'),(1,2,'GT2')]:
  a=hits[r['F_id'],gt];b=hits[r['R_id'],gt];found=set()
  for key in a.keys()&b.keys():
   if any(fm<=limit and rm<=limit and 0<=rp-fp-len(r['F'])<=1000 for fp,fm in a[key] for rp,rm in b[key]):found.add(key[0])
  r[col]=sorted(found)
 if len(r['WC3'])<=5 and len(r['GT2'])<=5:rows.append(r)
base=json.loads((p/'pool.json').read_text());(p/'combined_pool.json').write_text(json.dumps(base+rows));print('extended eligible',len(rows))
