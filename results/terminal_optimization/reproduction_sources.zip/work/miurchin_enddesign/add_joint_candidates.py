from pathlib import Path
prefix=Path(__file__).with_name('choose_joint.py').read_text().split('def metrics')[0]
exec(compile(prefix,str(Path(__file__).with_name('choose_joint.py')),'exec'))
from Bio import SeqIO
from Bio.Seq import Seq
import collections,subprocess
seq={x.id:str(x.seq).upper() for x in SeqIO.parse(root/'outputs/MiUrchin/analysis/target_aligned.fasta','fasta')};cols=[i for i,c in enumerate(seq['NC_001453.1']) if c!='-'];rev={frozenset(v):k for k,v in I.items()};groups=collections.defaultdict(list)
for r in rr:
 if r['region'] in ['L','XL'] and r['degeneracy_F']*r['degeneracy_R']==1:groups[r['region'],locus(r)].append(r)
extra=[];ext=json.loads((p/'extended_oligos.json').read_text());seen={};newol=[]
def make(q,side,a,b,reg):
 key=(q,side,a,b)
 if key in seen:return seen[key]
 name='J'+str(len(newol));cv=[];ex=[]
 for x in panel:
  s=seq[x['accession']][cols[max(0,a-6)]:cols[min(len(cols)-1,b+4)]+1].replace('-','')
  if side=='R':s=str(Seq(s).reverse_complement())
  mm=[]
  for i in range(len(s)-len(q)+1):
   t=s[i:i+len(q)]
   if set(t)<=set('ACGT'):
    z=[c not in I[n] for n,c in zip(q,t)];mm.append((sum(z),sum(z[-3:])))
  cv.append(any(n<=2 and z==0 for n,z in mm));ex.append(any(n==0 for n,z in mm))
 row=dict(id=name,region=reg,side=side,sequence=q,left=a-1,right=b,cv=cv,ex=ex);seen[key]=row;newol.append(row);return row
for (reg,loc),g in groups.items():
 unique={(r['F'],r['R']):r for r in g};g=list(unique.values())
 for x,y in itertools.combinations(g,2):
  F=''.join(rev[frozenset(I[a]+I[b])] for a,b in zip(x['F'],y['F']));R=''.join(rev[frozenset(I[a]+I[b])] for a,b in zip(x['R'],y['R']))
  if len(expand(F))*len(expand(R))>64 or not terminal_ok(F) or not terminal_ok(R):continue
  f=make(F,'F',*loc[:2],reg);r=make(R,'R',*loc[2:],reg)
  extra.append(dict(region=reg,F=F,R=R,F_id=f['id'],R_id=r['id'],source='terminal_adjustment',cv=(np.array(f['cv'])&r['cv']).tolist(),ex=(np.array(f['ex'])&r['ex']).tolist(),degeneracy_F=len(expand(F)),degeneracy_R=len(expand(R))))
extra=list({(r['region'],r['F_id'],r['R_id']):r for r in extra}.values());print('new pairs',len(extra),'oligos',len(newol),flush=True)
(p/'joint_extra_pairs.json').write_text(json.dumps(extra));(p/'extended_oligos.json').write_text(json.dumps(ext+newol));d=p/'joint_sites';d.mkdir(exist_ok=True);(d/'oligos.tsv').write_text(''.join(f"{r['id']} {r['side']} {r['sequence']}\n" for r in newol));subprocess.run([str(root/'work/miurchin_mifish/specific/scan_sites'),str(d)],check=True)
hits=collections.defaultdict(lambda:collections.defaultdict(list))
for n,acc,ori,gt,pos,mm,last in csv.reader((d/'background_sites.tsv').open(),delimiter='\t'):hits[n,int(gt)][acc,ori].append((int(pos),int(mm)))
accepted=[]
for r in extra:
 for gt,lim,key in [(0,3,'WC3'),(1,2,'GT2')]:
  a,b=hits[r['F_id'],gt],hits[r['R_id'],gt];r[key]=[acc for acc,ori in a.keys()&b.keys() if any(fm<=lim and rm<=lim and 0<=rp-fp-len(r['F'])<=1000 for fp,fm in a[acc,ori] for rp,rm in b[acc,ori])];r[key]=sorted(set(r[key]))
 if len(r['WC3'])<=5 and len(r['GT2'])<=5:accepted.append(r)
(p/'joint_extra_feasible.json').write_text(json.dumps(accepted));print('accepted',len(accepted),flush=True)
