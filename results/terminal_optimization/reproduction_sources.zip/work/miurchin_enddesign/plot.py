from pathlib import Path
import csv,json,html,collections
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Data.IUPACData import ambiguous_dna_values as I
p=Path(__file__).resolve().parent;root=p.parents[1];out=p/'release';rr=json.loads((p/'selected_strict.json').read_text());panel=json.loads((root/'work/miurchin_mifish/panel.json').read_text());seq={r.id:str(r.seq).upper() for r in SeqIO.parse(root/'outputs/MiUrchin/analysis/target_aligned.fasta','fasta')};cols=[i for i,b in enumerate(seq['NC_001453.1']) if b!='-'];ol={src:{x['id']:x for x in json.loads((root/'work/miurchin'/src/'oligos.json').read_text())} for src in ['same_locus','same_locus_common_panel']};shift={x['name']:x for x in csv.DictReader((root/'work/miurchin_mifish/specific/oligos.csv').open())}
ol['terminal_adjustment']={x['id']:x for x in json.loads((p/'extended_oligos.json').read_text())}
htmlparts=[]
def colour(q,ch):
 if ch not in 'ACGT':return '#e5e7eb'
 if ch in I[q]:return '#d7edf5'
 if any((x,ch) in [('G','A'),('T','C')] for x in I[q]):return '#e5d6fa'
 return '#ffd3a3'
for reg in ['S','M','L','XL']:
 for chem in ['ordinary','degenerate']:
  pairs=[r for r in rr if r['region']==reg and (r['chemistry']=='ordinary' if chem=='ordinary' else r['chemistry']!='ordinary')];elements=[];y=85
  for r in pairs:
   for side in ['F','R']:
    q=r[side];meta=shift[r[side+'_id']] if r['source']=='mifish_shifted' else ol[r['source']][r[side+'_id']]
    a,b=(int(meta['start'])-1,int(meta['end'])) if r['source']=='mifish_shifted' else (int(meta['left']),int(meta['right']))
    groups=collections.defaultdict(list)
    for item in panel:
     s=seq[item['accession']][cols[max(0,a-5)]:cols[b+4]+1].replace('-','')
     if side=='R':s=str(Seq(s).reverse_complement())
     windows=[s[i:i+len(q)] for i in range(len(s)-len(q)+1)]
     def score(t):
      mm=[c not in I[x] for x,c in zip(q,t)];return (not (sum(mm)<=2 and not any(mm[-3:])),sum(mm),sum(mm[-3:]))
     t=min(windows,key=score) if windows else '?'*len(q);groups[item['order'],t].append(item)
    title=f"{r['name']} / {side} | degeneracy {r['degeneracy_'+side]} | site {a+1}–{b}"
    htmlparts.append('<h3>'+html.escape(title)+'</h3><table><tr><th>Primer 5′→3′</th><td>'+''.join(f'<span>{c}</span>' for c in q)+'</td></tr>')
    for (order,t),items in sorted(groups.items()):htmlparts.append('<tr><td>'+html.escape(order+' / '+items[0]['organism']+' / '+items[0]['accession'])+f' ({len(items)})</td><td>'+''.join(f'<span style="background:{colour(x,c)};border-bottom:{"3px solid #173647" if j>=len(q)-3 else "none"}">{c}</span>' for j,(x,c) in enumerate(zip(q,t)))+'</td></tr>')
    htmlparts.append('</table>')
    representatives=[]
    for order in sorted(set(key[0] for key in groups)):
     (o,t),items=max([(k,v) for k,v in groups.items() if k[0]==order],key=lambda kv:sum(float(x['weight']) for x in kv[1]));representatives.append((order+' / '+items[0]['accession'],t))
    records=[('Primer 5′ → 3′',q)]+representatives;elements.append(f'<text x="24" y="{y}" font-size="18">{html.escape(title)}</text>');y+=15
    for label,t in records:
     elements.append(f'<text x="24" y="{y+20}" font-size="13">{html.escape(label)}</text>')
     for i,ch in enumerate(t):
      c='#d7edf5' if label.startswith('Primer') else colour(q[i],ch);x=390+22*i;elements.append(f'<rect x="{x}" y="{y}" width="21" height="28" fill="{c}"/><text x="{x+6}" y="{y+20}" font-family="monospace" font-size="16">{ch}</text>')
     y+=30
    elements.append(f'<rect x="{390+22*(len(q)-3)}" y="{y-30*len(records)}" width="66" height="{30*len(records)}" fill="none" stroke="#173647" stroke-width="2"/>');y+=45
  label=reg+('D' if chem=='degenerate' else '')
  (out/f'base_matching_{label}.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="{y}"><rect width="100%" height="100%" rx="18" fill="#f7fafc"/><g font-family="Arial" fill="#173647"><text x="24" y="30" font-size="23">MiUrchin {label} | Primer–template alignment</text><text x="24" y="55" font-size="13">Blue: IUPAC-compatible · Orange: mismatch · Purple: possible G–T · Box: terminal 3 nt · Representative per order</text>'+''.join(elements)+'</g></svg>')
(out/'base_matching.html').write_text('<meta charset="utf-8"><title>MiUrchin base matching</title><style>body{font:16px system-ui;margin:30px;color:#173647}table{border-collapse:collapse}td{padding:3px;border-bottom:1px solid #ddd}td:last-child{white-space:nowrap}span{display:inline-block;width:18px;font:15px monospace;text-align:center;padding:5px 0}</style><h1>MiUrchin：普通与简并引物碱基匹配</h1><p>蓝色为IUPAC相容，橙色为错配，紫色为可能的G–T配对，灰色为不可判定。引物和同向参考均按5′→3′显示；反向位点已反向互补。去除比对缺口后，在种子窗口±5 nt内选择最佳真实片段；完整产物判定见独立扫描结果。</p>'+''.join(htmlparts))
