from pathlib import Path
import json,csv,html
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Data.IUPACData import ambiguous_dna_values as I
p=Path(__file__).resolve().parent;root=p.parents[1];out=p/'release';rr=json.loads((p/'selected_strict.json').read_text());ol={src:{x['id']:x for x in json.loads((root/'work/miurchin'/src/'oligos.json').read_text())} for src in ['same_locus','same_locus_common_panel']};ol['terminal_adjustment']={x['id']:x for x in json.loads((p/'extended_oligos.json').read_text())};sh={x['name']:x for x in csv.DictReader((root/'work/miurchin_mifish/specific/oligos.csv').open())};ref=next(str(x.seq).upper().replace('-','') for x in SeqIO.parse(root/'outputs/MiUrchin/analysis/target_aligned.fasta','fasta') if x.id=='NC_001453.1')
rows=[]
for r in {x['name']:x for x in rr}.values():
 d=dict(name=r['name'],region=r['region'],reference='NC_001453.1')
 for side in ['F','R']:
  m=(sh if r['source']=='mifish_shifted' else ol[r['source']])[r[side+'_id']];a,b=(int(m['start'])-1,int(m['end'])) if r['source']=='mifish_shifted' else (m['left'],m['right']);t=ref[a:b];t=str(Seq(t).reverse_complement()) if side=='R' else t;q=r[side];assert len(t)==len(q),(r['name'],side,a,b,len(q));d.update({side+'_start':a+1,side+'_end':b,side+'_sequence':q,side+'_reference_5to3':t,side+'_reference_mismatches':sum(c not in I[n] for n,c in zip(q,t))})
 d['reference_span_bp']=d['R_end']-d['F_start']+1;rows.append(d)
with (out/'binding_positions.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
colors=dict(S='#13aaba',M='#e59b19',L='#2779ef',XL='#922bde');W=1700;H=210+len(rows)*60;left=160;right=1570;x=lambda pos:left+pos*(right-left)/1400
els=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}"><rect width="100%" height="100%" rx="22" fill="#f7fbff"/><g font-family="Arial,sans-serif" fill="#173647">','<text x="34" y="40" font-size="27" font-weight="bold">MiUrchin | Current primer binding positions</text>','<text x="34" y="72" font-size="17">NC_001453.1 · Extracted 16S rRNA · 1-based, ungapped · Shared linear scale</text>']
for tick in range(0,1401,100):
 xx=x(tick);els.append(f'<line x1="{xx}" x2="{xx}" y1="110" y2="{H-80}" stroke="#deebf3"/><text x="{xx}" y="103" text-anchor="middle" font-size="14">{tick}</text>')
for i,r in enumerate(rows):
 y=145+i*60;c=colors[r['region']];a,b=x(r['F_start']),x(r['F_end']);u,v=x(r['R_start']),x(r['R_end'])
 els.extend([f'<text x="35" y="{y+6}" fill="{c}" font-size="22" font-weight="bold">{r["name"]}</text>',f'<line x1="{a}" x2="{v}" y1="{y}" y2="{y}" stroke="{c}" stroke-opacity=".32" stroke-width="5"/>',f'<path d="M{a},{y-5} H{b-6} V{y-9} L{b},{y} L{b-6},{y+9} V{y+5} H{a} Z" fill="{c}"/>',f'<path d="M{v},{y-5} H{u+6} V{y-9} L{u},{y} L{u+6},{y+9} V{y+5} H{v} Z" fill="{c}"/>',f'<text x="{(a+v)/2}" y="{y-12}" text-anchor="middle" font-size="15" fill="{c}">{r["reference_span_bp"]} bp</text>',f'<text x="{a}" y="{y+24}" text-anchor="middle" font-size="14">F {r["F_start"]}–{r["F_end"]}</text>',f'<text x="{v}" y="{y+24}" text-anchor="middle" font-size="14">R {r["R_start"]}–{r["R_end"]}</text>'])
els.extend([f'<text x="{(left+right)/2}" y="{H-47}" text-anchor="middle" font-size="17">Position on extracted 16S rRNA (bp)</text>',f'<text x="34" y="{H-18}" font-size="14">Arrows show current homologous binding intervals, including reference mismatches; spans include primers. Product sizes vary among taxa.</text>','</g></svg>']);(out/'binding_positions.svg').write_text(''.join(els))
print('mapped',len(rows),'pair names; all interval lengths equal primer lengths')
