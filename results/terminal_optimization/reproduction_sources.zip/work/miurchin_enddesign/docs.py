from pathlib import Path
import csv,json,zipfile
p=Path(__file__).resolve().parent;root=p.parents[1];repo=root/'outputs/MiUrchin';dest=repo/'results/terminal_optimization'
methods_en='''# Methods

[中文](METHODS.zh-CN.md)

## Reference panel and candidate search

The common panel has 49 taxonomic labels and 80 haplotypes, weighted equally by label and then within label. Frozen target and background FASTA files contain 1,401 and 6,045 records. Coordinates refer to extracted, ungapped NC_001453.1 16S rRNA, not the complete mitogenome.

The initial pool contains observed and consensus primers from four homologous windows. The terminal-correction round adds 3′ shortening and extension by up to 6 bases around previously selected S/M oligos, retaining lengths 18–32 nt. Extensions use up to three observed flank sequences. IUPAC restrictions can remove concrete variants with long homopolymers without adding a base outside the original ambiguity code. Existing L/XL candidates remain available. This is a bounded candidate search.

## Terminal and thermodynamic constraints

Every concrete IUPAC variant must have: no terminal homotriplet; at least one G/C in the final three bases; 1–4 G/C in the final five bases; and no homopolymer longer than four bases anywhere. These are project-specific conservative filters informed by [Thermo Fisher guidance](https://www.thermofisher.com/blog/behindthebench/pcr-primer-design-tips/) and [Primer3 parameters](https://primer3.org/manual.html). A G/C at the very last base is not mandatory. Four-base internal runs can remain.

Primer3 uses 50 mM monovalent salt, 1.5 mM Mg²⁺ and 0.6 mM dNTP. Expand all concrete variants under two scenarios: 50 nM per variant, and 200 nM per direction divided equally among variants. Hairpin, homodimer, within-direction heterodimer and F/R heterodimer Tm must be below 55°C. The difference between F and R Tm-range midpoints must be ≤5°C in both scenarios; this does not constrain every cross-variant Tm difference. Unequal-concentration heterodimers use the larger concentration as an approximation.

The terminal audit also reports Primer3 end-stability ΔG at 37°C for each terminal 5-mer against its perfect reverse complement, at the stated salts and 200 nM. Variant minima/maxima are reported in kcal/mol. This descriptive calculation has no fitted pass/fail threshold and is not a prediction of PCR yield.

## Selection and independent verification

Target coverage permits ≤2 mismatches per primer and requires exact IUPAC compatibility in the last three bases. Exact matching requires zero mismatches in both primers. Target products must be 150–500 bp with ≥50 internal bases. Background scans cover both strands, correct orientation and 0–1,000 nt internal distance. Each portfolio allows at most five WC≤3 and five GT≤2 background accessions; WC≤4 is reported as a more permissive sensitivity result.

S/M/XL selections maximize the equally weighted sum of coverage and exact matching, then coverage, exact matching, lower total degeneracy and fewer background accessions. This explicitly trades some coverage for exact matching. L retains its coverage-first ranking because the prior selected pairs pass the terminal rules. Two-pair mixed portfolios reuse the selected degenerate single pair plus one ordinary pair. Identical target/background states are reduced to the lowest-degeneracy representative before selection; this bounded reduction is not a proof of global optimality.

A separate C++ all-window paired-product scanner verifies the selected sequences without the candidate scanner's early-rejection filter. The published verification contains 2,880 target-state checks with zero disagreements. The 12 portfolios contain 18 paired rows and 14 pair names / 28 exported oligos. Metrics are separate-PCR unions, not validated multiplex performance. Wet-lab validation is pending.

## Coordinate and base-matching figures

The position map is generated directly from each selected oligo's reference interval on one linear scale. Interval lengths are checked against oligo lengths. Homologous intervals can contain mismatches to NC_001453.1; reference bases and mismatch counts are included in the coordinate table. The representative SD, MD, L and XL spans are 188, 228, 343 and 440 bp, respectively. Base-matching diagrams show actual bases oriented 5′→3′ and mark the terminal three bases.

Design context: [Miya et al. 2015](https://doi.org/10.1098/rsos.150088). [Reproduction](REPRODUCIBILITY.md).
'''
methods_zh='''# 方法

[English](METHODS.md)

## 参考面板与候选搜索

共同面板包含49个分类名称标签、80个单倍型，标签等权、标签内单倍型等权。冻结目标与背景FASTA分别含1,401与6,045条记录。坐标以NC_001453.1提取、去缺口的16S序列为准，不是完整线粒体基因组坐标。

初始候选来自四个同源窗口的真实序列与共识序列。本轮在既有S/M候选的3′端尝试最多6个碱基的缩短或延长，保留18–32 nt；延长部分取最多三种实际观察到的侧翼序列。对可能形成长串同碱基的简并序列，限制部分IUPAC位点以去掉这些实际变体，不引入原简并代码以外的碱基。L/XL继续使用既有候选池。搜索范围有限。

## 末端与热力学约束

展开后的每条实际变体必须满足：3′端不出现三连同碱基；末端3位至少含1个G/C；末端5位含1–4个G/C；整条序列连续同碱基不超过4个。规则参考[Thermo Fisher设计建议](https://www.thermofisher.com/blog/behindthebench/pcr-primer-design-tips/)与[Primer3参数](https://primer3.org/manual.html)，是本项目采用的筛选条件，不是统一实验成功阈值。最后一位不强制为G/C，内部仍可能存在四连同碱基。

Primer3条件为单价盐50 mM、Mg²⁺ 1.5 mM、dNTP 0.6 mM。全部变体分别在每变体50 nM、每方向总量200 nM均分两种情景下评估。发卡、同源二聚体、同向异源二聚体及F/R异源二聚体Tm须低于55°C；两种情景中，F与R的Tm范围中点差均须≤5°C。这不表示任意两个具体变体的Tm差均≤5°C。浓度不等时，二聚体取较大浓度近似。

末端审计另列最后5 nt与其完全反向互补序列的Primer3末端稳定性ΔG：37°C、上述盐条件、200 nM，单位kcal/mol，报告全部变体的最小值与最大值。该值用于描述性比较，未设经过实验标定的通过阈值，也不代表PCR产量。

## 选择与独立复核

覆盖允许每条引物≤2处错配，但末端3位须IUPAC完全相容；完全匹配要求F/R均为零错配。目标产物限制150–500 bp、内部序列≥50 nt。背景扫描两条链，要求方向正确、内部距离0–1,000 nt。每套组合WC≤3及GT≤2各允许最多5条背景accession；另列WC≤4宽松敏感性结果。

S/M/XL先最大化覆盖率与完全匹配率的等权和，再按覆盖、完全匹配、较低总简并度、较少背景命中排序，允许以部分覆盖换取完全匹配。L的原选配对通过末端规则，因此继续采用覆盖优先排序。混合两对方案复用已选简并单对，加一对普通引物。相同目标/背景命中状态先保留低简并度代表；这种有限候选归并不保证全局最优。

独立C++程序不使用候选扫描的早停过滤，重新扫描完整配对产物；共2,880项目标状态检查，差异为零。当前12套方案、18条配对记录、14个配对名及28条导出序列。两对指标为独立PCR的并集，不是已验证的混池效果；尚待实验验证。

## 位置图与碱基匹配图

位置图直接从每条入选引物的参考区间生成，全部使用同一线性比例，并检查区间长度等于引物长度。参考同源位点可能与该引物存在错配，坐标表列出参考碱基及错配数。SD、MD、L、XL的参考跨度分别为188、228、343、440 bp。碱基图显示5′→3′实际序列并框出末端3位。

设计参考：[Miya等，2015](https://doi.org/10.1098/rsos.150088)。[复现](REPRODUCIBILITY.md)。
'''
(repo/'docs/METHODS.md').write_text(methods_en);(repo/'docs/METHODS.zh-CN.md').write_text(methods_zh)
comp=list(csv.DictReader((dest/'comparison.csv').open()));old={x['scheme']:x for x in csv.DictReader((dest/'previous_comparison.csv').open())}
lines=['# Terminal correction / 末端修正','', '## Material Passport','', 'Verification status: VERIFIED for the frozen computational panel; wet-lab validation pending. / 冻结面板计算复核通过，实验验证待完成。','', 'Scope: candidate redesign, full-sequence verification and coordinate correction. No hypothesis tests or population-wide confidence intervals are inferred from this optimization panel. / 范围为候选修正、全序列复核与坐标校正，不从优化面板推断总体置信区间或假设检验结论。','', '## Results / 结果','', '| Scheme | Previous coverage / exact | Current coverage / exact |','|---|---:|---:|']
for r in comp:
 oldr=old['MD+MC' if r['scheme']=='MD+MB' else r['scheme']];lines.append(f"| {r['scheme']} | {float(oldr['coverage_pct']):.2f}% / {float(oldr['exact_pct']):.2f}% | {float(r['coverage_pct']):.2f}% / {float(r['exact_pct']):.2f}% |")
lines+=['','All 28 current oligos pass terminal filters across their concrete variants. Nine of the 30 previous named oligos fail at least one new terminal/homopolymer rule. Independent target checks: 2,880; disagreements: 0. / 当前28条引物的实际变体全部通过末端规则；上一版30条命名引物中9条不满足至少一项新规则。独立目标状态检查2,880项，差异0项。','','M improves or retains key metrics with fewer degenerate variants (MD F: 12→6). S pays a substantial exact-match cost after long-poly-T variants are excluded; ordinary S is not the preferred broad-coverage option. / MD正向简并度从12降至6，M主要指标改善或保留；S排除长串T变体后完全匹配率明显下降，普通S不作为广覆盖首选。','','A provisional 91.84%-coverage MD single pair was rejected because the F/R Tm-range midpoint difference exceeded 5°C under fixed total directional concentration. Its results are not the published MD single-pair metrics. / 一个暂定覆盖91.84%的MD单对因固定同向总浓度下Tm范围中点差超过5°C被淘汰，未作为当前MD发布。','','[Terminal audit](../results/terminal_optimization/terminal_audit.csv) · [Thermodynamics](../results/terminal_optimization/thermal.csv) · [Independent checks](../results/terminal_optimization/verification.json) · [Missed references](../results/terminal_optimization/missed_references.csv) · [Coordinates](../results/current/binding_positions.csv)','','The coordinate map now uses all current intervals on a shared scale. In particular, L is F 932–961 and R 1250–1274: 343 bp on NC_001453.1, replacing the old seed-window 324 bp illustration. / 当前位置图按共同线性坐标绘制全部入选区间；L为F 932–961、R 1250–1274，参考跨度343 bp，已替换旧设计窗口324 bp的图示。','','[Methods / 方法](METHODS.md) · [中文方法](METHODS.zh-CN.md) · [Reproduction / 复现](REPRODUCIBILITY.md)']
(repo/'docs/TERMINAL_VALIDATION.md').write_text('\n'.join(lines)+'\n')
f=repo/'docs/REPRODUCIBILITY.md';s=f.read_text().replace('the compact checker validates the current 1–2-pair exports','the compact checker validates the retained earlier ordinary-primer exports').replace('compact检查器校验当前1–2对方案','compact检查器校验保留的早期普通引物方案');s+='''

## Current terminal-corrected release / 当前末端修正版

Install `requirements-compact.txt`, then extract [the terminal source bundle](../results/terminal_optimization/reproduction_sources.zip) into a fresh directory. It contains the frozen combined candidate pool, reference sequences, coordinates and scanner source. Selection, independent verification, base-matching and coordinate figures are reproducible without database downloads. / 安装依赖并解压源码包，即可从冻结候选池重算选择、独立复核及图件，不重新下载数据库。

```sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python work/miurchin_enddesign/optimize_strict.py
mkdir -p work/miurchin_mifish/verify
c++ -O3 -std=c++17 work/micucumber_nondegenerate/independent_scan.cpp -o work/miurchin_mifish/verify/scanner
python work/miurchin_enddesign/verify.py
python work/miurchin_enddesign/summarize.py
python work/miurchin_enddesign/plot.py
python work/miurchin_enddesign/positions.py
python work/miurchin_enddesign/end_audit.py
```

Outputs: `work/miurchin_enddesign/release/`. Check the published release with `python scripts/check_current.py`, `python scripts/check_terminal.py` and `python check_release.py`. / 输出位于上述目录；使用三项检查验证当前发布文件。

The optional `extend.py` and `merge_extended.py` regenerate the added candidate pool, using the included `scan_sites.cpp` between them; upstream initial discovery remains frozen. / 扩展脚本可重新生成新增候选，二者之间需运行附带的位点扫描器；更早的初始候选发现仍采用冻结结果。
''';f.write_text(s)
coord=list(csv.DictReader((dest/'binding_positions.csv').open()));selected=[next(x for x in coord if x['name']==n) for n in ['SD','MD','L','XL']]
with (repo/'figures/overview_regions.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(selected[0]),lineterminator='\n');w.writeheader();w.writerows(selected)
(repo/'figures/overview_design.md').write_text('''# MiUrchin overview

The watercolor header is AI-assisted artwork based on the MiCucumber visual format. Animal illustrations are schematic. Badge lengths are current representative reference spans for SD, MD, L and XL: 188, 228, 343 and 440 bp.

Scientific coordinates are rendered separately as `binding_positions.svg` from the selected oligo intervals by `positions.py`. All rows use one linear coordinate scale; arrows point toward the amplified interval. Exact coordinates, primer/reference sequences and mismatch counts are in `results/current/binding_positions.csv`. The map shows homologous binding intervals, not guaranteed amplification of the reference accession by every pair.
''')
f=repo/'CHANGELOG.md';f.write_text('# Terminal correction and coordinate map\n\n- Replace terminal homotriplets and all-AT terminal triplets; check every concrete IUPAC variant, internal homopolymers and two concentration scenarios.\n- Publish 12 portfolios with 14 pair names; reuse SD+SB and MD+MB.\n- Regenerate all base-matching figures and both READMEs.\n- Draw every current binding interval on one linear axis; correct the representative L reference span to 343 bp.\n\n'+f.read_text())
files=[p/n for n in ['optimize_strict.py','verify.py','summarize.py','plot.py','positions.py','end_audit.py','extend.py','merge_extended.py','combined_pool.json','pool.json','extended_oligos.json','previous_pairs.csv','selected_strict.json','audit_strict.json']]
files += [root/'work/miurchin_mifish'/n for n in ['panel.json','specific/feasible.json','specific/oligo_states.json','specific/oligos.csv','specific/scan_sites.cpp']]
files += [root/'work/miurchin_sm/selected.json',root/'work/micucumber_nondegenerate/independent_scan.cpp']
files += [root/'work/miurchin'/src/'oligos.json' for src in ['same_locus','same_locus_common_panel']]
files += [repo/'analysis'/n for n in ['target.fasta','target_aligned.fasta','background.fasta']]
with zipfile.ZipFile(dest/'reproduction_sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,f.relative_to(root))
print('methods, validation, reproduction, coordinates and source bundle updated')
