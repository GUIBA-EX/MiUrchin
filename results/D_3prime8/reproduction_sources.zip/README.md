Run python3 verify.py with Python 3.10+ and a C++17 compiler. Recomputes five candidate target and background scans using frozen references; no network or external Python dependencies.
