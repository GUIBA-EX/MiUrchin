from pathlib import Path
import subprocess,sys
p=Path(__file__).resolve().parent
for n in ['search.py','background.py','choose_pairs.py','verify.py']:subprocess.run([sys.executable,str(p/n)],check=True)
