from pathlib import Path
import json,subprocess
p=Path(__file__).resolve().parent;pool=json.loads((p/'oligos.json').read_text());sites=p/'sites';sites.mkdir(exist_ok=True)
(p/'reused_background_sites.tsv').write_text('');(sites/'oligos.tsv').write_text(''.join(f"{r['id']} {r['side']} {r['sequence']}\n" for r in pool))
subprocess.run(['c++','-O3','-std=c++17','-pthread',str(p/'scan_sites.cpp'),'-o',str(p/'scan_sites')],check=True)
subprocess.run([str(p/'scan_sites'),str(sites)],check=True)
