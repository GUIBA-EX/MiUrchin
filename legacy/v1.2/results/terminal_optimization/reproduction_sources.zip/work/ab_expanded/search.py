from pathlib import Path
import sys,collections,subprocess
root=Path.cwd();species=sys.argv[1];sys.path.insert(0,str(root/'work/milily'));from common import *
folder={'MiCucumber':'micucumber_terminal','MiLily':'milily','MiUrchin':'miurchin_enddesign'}[species];p=root/'work'/folder;scratch=root/'work/ab_expanded'/species;scratch.mkdir(exist_ok=True);out=root/'outputs'/f'{species}_AB_expanded';out.mkdir(exist_ok=True)
selname='selected_strict.json' if species=='MiUrchin' else 'selected.json';rr=json.loads((scratch/'before_selected.json' if (scratch/'before_selected.json').exists() else p/selname).read_text());(scratch/'before_selected.json').write_text(json.dumps(rr,indent=2));coords={r['name']:r for r in read(p/'release/binding_positions.csv')};ref={'MiCucumber':'AB525437.1','MiLily':'AF049132.1','MiUrchin':'NC_001453.1'}[species]
if species=='MiUrchin':panel=json.loads((root/'work/miurchin_mifish/panel.json').read_text());aln=root/'outputs/MiUrchin/analysis/target_aligned.fasta';bg=root/'outputs/MiUrchin/analysis/background.fasta'
else:panel=read(p/'panel.csv');aln=p/'target_aligned.fasta';bg=p/'background.fasta'
w=np.array([float(x['weight']) if not(species=='MiCucumber' and x['order']=='Apodida') else 0 for x in panel]);w/=w.sum();seq={x.id:str(x.seq).upper() for x in SeqIO.parse(aln,'fasta')};cols=[i for i,c in enumerate(seq[ref]) if c!='-'];ols=[]
def bits(v):return sum(1<<i for i,x in enumerate(v) if x)
wm=collections.defaultdict(int)
for i,weight in enumerate(w):wm[float(weight)]|=1<<i
def score(v):return sum(weight*(v&mask).bit_count() for weight,mask in wm.items())
for reg in ['S','M','L','XL']:
 for side in ['F','R']:
  a,b=[int(coords[reg][side+'_'+k]) for k in ['start','end']];length=b-a+1;qs=set();observed=collections.Counter();windows=[]
  for item,wt in zip(panel,w):
   s=seq.get(item['accession'],'')[cols[a-1]:cols[b-1]+1].replace('-','');s=str(Seq(s).reverse_complement()) if side=='R' else s
   if len(s)==length and set(s)<=set('ACGT'):qs.add(s);observed[s]+=wt
   s=seq.get(item['accession'],'')[cols[max(0,a-6)]:cols[min(len(cols)-1,b+4)]+1].replace('-','');windows.append(str(Seq(s).reverse_complement()) if side=='R' else s)
  for r in rr:
   if r['region']==reg:qs.update(expand(r[side]))
  if observed:
   counts=[collections.Counter() for _ in range(length)]
   for q,wt in observed.items():
    for j,c in enumerate(q):counts[j][c]+=wt
   majority=''.join(ct.most_common(1)[0][0] for ct in counts);qs.add(majority)
   # Supported one- and two-position consensus alternatives, not only observed haplotypes.
   alt=[(j,c) for j,ct in enumerate(counts) for c,wt in ct.items() if c!=majority[j] and wt/sum(ct.values())>=.01]
   for combo in [(x,) for x in alt]+list(itertools.combinations(alt,2)):
    if len({j for j,c in combo})!=len(combo):continue
    q=list(majority)
    for j,c in combo:q[j]=c
    qs.add(''.join(q))
  for q in sorted(qs):
   if not terminal(q):continue
   if any(t[2]>=55 for t in oligo_thermal(q)):continue
   cv=[];ex=[]
   for s in windows:
    hits=[]
    for i in range(len(s)-length+1):
     t=s[i:i+length]
     if set(t)<=set('ACGT'):
      z=[x!=y for x,y in zip(q,t)];hits.append((sum(z),sum(z[-3:])))
    cv.append(any(n<=2 and e==0 for n,e in hits));ex.append(any(n==0 for n,e in hits))
   if w@cv==0:continue
   ols.append(dict(id='ABX'+str(len(ols)),region=reg,side=side,sequence=q,start=a,end=b,left=a-1,right=b,degeneracy=1,cv=cv,ex=ex,_cv=bits(cv),_ex=bits(ex)))
print(species,'expanded oligos',len(ols),flush=True);(scratch/'oligos.json').write_text(json.dumps(ols));sites=scratch/'sites';sites.mkdir(exist_ok=True);(sites/'oligos.tsv').write_text(''.join(f"{x['id']} {x['side']} {x['sequence']}\n" for x in ols));link=scratch/'background.fasta'
if not link.exists():link.symlink_to(bg.resolve())
subprocess.run([str(root/'work/miurchin_mifish/specific/scan_sites'),str(sites)],check=True)
h=collections.defaultdict(lambda:collections.defaultdict(list))
for n,acc,ori,gt,pos,mm,last in csv.reader((sites/'background_sites.tsv').open(),delimiter='\t'):h[n,int(gt)][acc,ori].append((int(pos),int(mm)))
def background(f,r,gt,lim):
 a,b=h[f['id'],gt],h[r['id'],gt];return sorted({acc for acc,ori in a.keys()&b.keys() if any(fm<=lim and rm<=lim and 0<=rp-fp-len(f['sequence'])<=1000 for fp,fm in a[acc,ori] for rp,rm in b[acc,ori])})
chosen=[];audit=[];feasible=[]
for reg in ['S','M','L','XL']:
 pool=[]
 for f,r in itertools.product([x for x in ols if x['region']==reg and x['side']=='F'],[x for x in ols if x['region']==reg and x['side']=='R']):
  cv=f['_cv']&r['_cv'];ex=f['_ex']&r['_ex']
  if score(cv)==0:continue
  ft,rt=oligo_thermal(f['sequence']),oligo_thermal(r['sequence'])
  if any(abs((a[0]+a[1]-b[0]-b[1])/2)>5 for a,b in zip(ft,rt)):continue
  wc=background(f,r,0,3)
  if len(wc)>5:continue
  gt=background(f,r,1,2)
  if len(gt)>5:continue
  if not thermal(f['sequence'],r['sequence'])[0]:continue
  pool.append(dict(region=reg,F=f['sequence'],R=r['sequence'],F_id=f['id'],R_id=r['id'],degeneracy_F=1,degeneracy_R=1,cv=(np.array(f['cv'])&r['cv']).tolist(),ex=(np.array(f['ex'])&r['ex']).tolist(),WC3=wc,GT2=gt,_cv=cv,_ex=ex))
 print(reg,'feasible pairs',len(pool),flush=True);feasible+=pool
 # Identical target/background states are interchangeable for the union objective after thermal validation.
 unique={}
 for x in pool:unique.setdefault((x['_cv'],x['_ex'],tuple(x['WC3']),tuple(x['GT2'])),x)
 reduced=list(unique.values());best=None;bestpair=None
 for a,b in itertools.combinations(reduced,2):
  wc=set(a['WC3'])|set(b['WC3']);gt=set(a['GT2'])|set(b['GT2'])
  if len(wc)>5 or len(gt)>5:continue
  c=score(a['_cv']|b['_cv']);e=score(a['_ex']|b['_ex']);au=score(a['_cv']&~b['_cv'])+score(a['_ex']&~b['_ex']);bu=score(b['_cv']&~a['_cv'])+score(b['_ex']&~a['_ex'])
  key=(round(c+e,12),round(min(au,bu),12),round(c,12),-len(wc)-len(gt))
  if best is None or key>best:best=key;bestpair=(a,b);metrics=(c,e,au,bu)
 if bestpair is None:raise RuntimeError((reg,'no distinct-state pair'))
 c,e,au,bu=metrics;recommended=min(au,bu)>1e-9
 for i,x in enumerate(bestpair):chosen.append(dict(x,name=reg+chr(65+i),scheme=reg+'A+'+reg+'B',chemistry='ordinary',option=2,thermal=thermal(x['F'],x['R'])[1],source='terminal_adjustment',union_coverage=c,union_exact=e))
 audit.append(dict(region=reg,feasible_pairs=len(pool),distinct_states=len(reduced),coverage_pct=100*c,exact_pct=100*e,A_unique_combined=100*au,B_unique_combined=100*bu,recommended=recommended));print(audit[-1],flush=True)
(scratch/'selected.json').write_text(json.dumps(chosen,indent=2));(scratch/'feasible.json').write_text(json.dumps(feasible));write(out/'search_audit.csv',audit);print('DONE',flush=True)
